<?php
// api/suppliers.php

// CRITICAL: Ensure NO whitespace, BOM, or any characters before this opening PHP tag.

require_once __DIR__ . '/../config/config.php';

$conn = getDbConnection();
ob_start();

authenticate_user(); // Suppliers can be managed by authenticated users

$method = $_SERVER['REQUEST_METHOD'];

switch ($method) {
    case 'GET':
        handleGetSuppliers($conn);
        break;
    case 'POST':
        handleCreateSupplier($conn);
        break;
    case 'PUT':
        handleUpdateSupplier($conn);
        break;
    case 'DELETE':
        handleDeleteSupplier($conn);
        break;
    default:
        sendJsonResponse(['success' => false, 'message' => 'Method Not Allowed'], 405);
        break;
}

function handleGetSuppliers($conn) {
    if (isset($_GET['id'])) {
        $supplier_id = sanitize_input($_GET['id']);
        $stmt = $conn->prepare("SELECT * FROM suppliers WHERE supplier_id = ?");
        $stmt->bind_param("i", $supplier_id);
        $stmt->execute();
        $result = $stmt->get_result();
        if ($supplier = $result->fetch_assoc()) {
            sendJsonResponse(['success' => true, 'data' => $supplier]);
        } else {
            sendJsonResponse(['success' => false, 'message' => 'Supplier not found'], 404);
        }
        $stmt->close();
    } else {
        $result = $conn->query("SELECT * FROM suppliers WHERE is_active = TRUE ORDER BY supplier_name ASC");
        if (!$result) {
            throw new Exception("Database query failed: " . $conn->error);
        }
        $suppliers = [];
        while ($row = $result->fetch_assoc()) {
            $suppliers[] = $row;
        }
        sendJsonResponse(['success' => true, 'data' => $suppliers]);
    }
}

function handleCreateSupplier($conn) {
    $input = json_decode(file_get_contents('php://input'), true);

    $supplier_name = sanitize_input($input['supplier_name'] ?? '');
    $contact_person = sanitize_input($input['contact_person'] ?? '');
    $email = sanitize_input($input['email'] ?? '');
    $phone = sanitize_input($input['phone'] ?? '');
    $address_line1 = sanitize_input($input['address_line1'] ?? '');
    $address_line2 = sanitize_input($input['address_line2'] ?? '');
    $city = sanitize_input($input['city'] ?? '');
    $state = sanitize_input($input['state'] ?? '');
    $zip_code = sanitize_input($input['zip_code'] ?? '');
    $country = sanitize_input($input['country'] ?? '');
    $payment_terms = sanitize_input($input['payment_terms'] ?? null);
    $tax_id = sanitize_input($input['tax_id'] ?? null);
    $is_active = isset($input['is_active']) ? (bool)$input['is_active'] : true;


    if (empty($supplier_name)) {
        sendJsonResponse(['success' => false, 'message' => 'Supplier Name is required'], 400);
    }

    $stmt = $conn->prepare("INSERT INTO suppliers (supplier_name, contact_person, email, phone, address_line1, address_line2, city, state, zip_code, country, payment_terms, tax_id, is_active) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("sssssssssssis", 
        $supplier_name, $contact_person, $email, $phone, $address_line1, $address_line2, 
        $city, $state, $zip_code, $country, $payment_terms, $tax_id, $is_active
    );

    if ($stmt->execute()) {
        sendJsonResponse(['success' => true, 'message' => 'Supplier created successfully', 'supplier_id' => $stmt->insert_id], 201);
    } else {
        if ($conn->errno == 1062) { // Duplicate entry for supplier_name
            sendJsonResponse(['success' => false, 'message' => 'Supplier name already exists.'], 409);
        } else {
            sendJsonResponse(['success' => false, 'message' => 'Failed to create supplier', 'error' => $conn->error], 500);
        }
    }
    $stmt->close();
}

function handleUpdateSupplier($conn) {
    $input = json_decode(file_get_contents('php://input'), true);

    $supplier_id = sanitize_input($input['supplier_id'] ?? '');
    if (empty($supplier_id)) {
        sendJsonResponse(['success' => false, 'message' => 'Supplier ID is required for update'], 400);
    }

    $supplier_name = sanitize_input($input['supplier_name'] ?? null);
    $contact_person = sanitize_input($input['contact_person'] ?? null);
    $email = sanitize_input($input['email'] ?? null);
    $phone = sanitize_input($input['phone'] ?? null);
    $address_line1 = sanitize_input($input['address_line1'] ?? null);
    $address_line2 = sanitize_input($input['address_line2'] ?? null);
    $city = sanitize_input($input['city'] ?? null);
    $state = sanitize_input($input['state'] ?? null);
    $zip_code = sanitize_input($input['zip_code'] ?? null);
    $country = sanitize_input($input['country'] ?? null);
    $payment_terms = sanitize_input($input['payment_terms'] ?? null);
    $tax_id = sanitize_input($input['tax_id'] ?? null);
    $is_active = array_key_exists('is_active', $input) ? (bool)$input['is_active'] : null;

    $set_clauses = [];
    $bind_params = [];
    $bind_types = "";

    if ($supplier_name !== null) { 
        $stmt_check = $conn->prepare("SELECT supplier_id FROM suppliers WHERE supplier_name = ? AND supplier_id != ?");
        $stmt_check->bind_param("si", $supplier_name, $supplier_id);
        $stmt_check->execute();
        if ($stmt_check->get_result()->num_rows > 0) {
            sendJsonResponse(['success' => false, 'message' => 'Supplier name already exists for another supplier.'], 409);
            $stmt_check->close();
            return;
        }
        $stmt_check->close();
        $set_clauses[] = "supplier_name = ?"; $bind_params[] = &$supplier_name; $bind_types .= "s"; 
    }
    if ($contact_person !== null) { $set_clauses[] = "contact_person = ?"; $bind_params[] = &$contact_person; $bind_types .= "s"; }
    if ($email !== null) { $set_clauses[] = "email = ?"; $bind_params[] = &$email; $bind_types .= "s"; }
    if ($phone !== null) { $set_clauses[] = "phone = ?"; $bind_params[] = &$phone; $bind_types .= "s"; }
    if ($address_line1 !== null) { $set_clauses[] = "address_line1 = ?"; $bind_params[] = &$address_line1; $bind_types .= "s"; }
    if ($address_line2 !== null) { $set_clauses[] = "address_line2 = ?"; $bind_params[] = &$address_line2; $bind_types .= "s"; }
    if ($city !== null) { $set_clauses[] = "city = ?"; $bind_params[] = &$city; $bind_types .= "s"; }
    if ($state !== null) { $set_clauses[] = "state = ?"; $bind_params[] = &$state; $bind_types .= "s"; }
    if ($zip_code !== null) { $set_clauses[] = "zip_code = ?"; $bind_params[] = &$zip_code; $bind_types .= "s"; }
    if ($country !== null) { $set_clauses[] = "country = ?"; $bind_params[] = &$country; $bind_types .= "s"; }
    if ($payment_terms !== null) { $set_clauses[] = "payment_terms = ?"; $bind_params[] = &$payment_terms; $bind_types .= "s"; }
    if ($tax_id !== null) { $set_clauses[] = "tax_id = ?"; $bind_params[] = &$tax_id; $bind_types .= "s"; }
    if ($is_active !== null) { $set_clauses[] = "is_active = ?"; $bind_params[] = &$is_active; $bind_types .= "i"; }


    if (empty($set_clauses)) {
        sendJsonResponse(['success' => true, 'message' => 'No fields provided for update or nothing to update.'], 200); 
        return; 
    }

    $sql = "UPDATE suppliers SET " . implode(", ", $set_clauses) . " WHERE supplier_id = ?";
    $bind_params[] = &$supplier_id;
    $bind_types .= "i";

    $stmt = $conn->prepare($sql);
    call_user_func_array([$stmt, 'bind_param'], array_merge([$bind_types], $bind_params));

    if ($stmt->execute()) {
        if ($stmt->affected_rows > 0) {
            sendJsonResponse(['success' => true, 'message' => 'Supplier updated successfully'], 200);
        } else {
            $stmt_check_exists = $conn->prepare("SELECT supplier_id FROM suppliers WHERE supplier_id = ?");
            $stmt_check_exists->bind_param("i", $supplier_id);
            $stmt_check_exists->execute();
            if ($stmt_check_exists->get_result()->num_rows > 0) {
                sendJsonResponse(['success' => true, 'message' => 'Supplier found, but no changes were made.'], 200);
            } else {
                sendJsonResponse(['success' => false, 'message' => 'Supplier not found'], 404);
            }
            $stmt_check_exists->close();
        }
    } else {
        sendJsonResponse(['success' => false, 'message' => 'Failed to update supplier', 'error' => $conn->error], 500);
    }
    $stmt->close();
}

function handleDeleteSupplier($conn) {
    if (!isset($_GET['id'])) {
        sendJsonResponse(['success' => false, 'message' => 'Supplier ID is required for deletion'], 400);
    }
    $supplier_id = sanitize_input($_GET['id']);

    // Check if supplier is referenced in inbound receipts
    $stmt_check_receipts = $conn->prepare("SELECT COUNT(*) FROM inbound_receipts WHERE supplier_id = ?");
    $stmt_check_receipts->bind_param("i", $supplier_id);
    $stmt_check_receipts->execute();
    $result_check = $stmt_check_receipts->get_result()->fetch_row();
    $stmt_check_receipts->close();

    if ($result_check[0] > 0) {
        sendJsonResponse(['success' => false, 'message' => 'Cannot delete supplier: It is referenced by existing inbound receipts.'], 400);
        return;
    }

    $stmt = $conn->prepare("DELETE FROM suppliers WHERE supplier_id = ?");
    $stmt->bind_param("i", $supplier_id);

    if ($stmt->execute()) {
        if ($stmt->affected_rows > 0) {
            sendJsonResponse(['success' => true, 'message' => 'Supplier deleted successfully'], 200);
        } else {
            sendJsonResponse(['success' => false, 'message' => 'Supplier not found'], 404);
        }
    } else {
        sendJsonResponse(['success' => false, 'message' => 'Failed to delete supplier', 'error' => $conn->error], 500);
    }
    $stmt->close();
}