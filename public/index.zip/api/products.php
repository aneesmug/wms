<?php
// api/products.php

require_once __DIR__ . '/../config/config.php';

$conn = getDbConnection();
ob_start();

// Authenticate user. A warehouse context is needed to determine the user's role,
// even for managing global data like products.
authenticate_user(true, null); 

$method = $_SERVER['REQUEST_METHOD'];

// Apply role-based authorization for each action
switch ($method) {
    case 'GET':
        // Any user with a role can view the product list.
        authorize_user_role(['viewer', 'operator', 'manager']);
        handleGetProducts($conn);
        break;
    case 'POST':
        // Only operators and managers can create new products.
        authorize_user_role(['operator', 'manager']);
        handleCreateProduct($conn);
        break;
    case 'PUT':
        // Only operators and managers can update products.
        authorize_user_role(['operator', 'manager']);
        handleUpdateProduct($conn);
        break;
    case 'DELETE':
        // Deleting products is a critical action, restricted to managers.
        authorize_user_role(['manager']);
        handleDeleteProduct($conn);
        break;
    default:
        sendJsonResponse(['success' => false, 'message' => 'Method Not Allowed'], 405);
        break;
}

function handleGetProducts($conn) {
    if (isset($_GET['id'])) {
        $product_id = filter_var($_GET['id'], FILTER_VALIDATE_INT);
        if (!$product_id) {
            sendJsonResponse(['success' => false, 'message' => 'Invalid Product ID.'], 400);
            return;
        }
        $stmt = $conn->prepare("SELECT product_id, sku, product_name, description, unit_of_measure, weight, volume, barcode FROM products WHERE product_id = ?");
        $stmt->bind_param("i", $product_id);
        $stmt->execute();
        $result = $stmt->get_result();
        if ($product = $result->fetch_assoc()) {
            sendJsonResponse(['success' => true, 'data' => $product]);
        } else {
            sendJsonResponse(['success' => false, 'message' => 'Product not found'], 404);
        }
        $stmt->close();
    } else {
        $result = $conn->query("SELECT product_id, sku, product_name, description, unit_of_measure, weight, volume, barcode FROM products ORDER BY product_name ASC");
        if (!$result) {
            error_log("handleGetProducts SQL Error: " . $conn->error);
            sendJsonResponse(['success' => false, 'message' => 'Database query failed for products list.'], 500);
            return;
        }
        $products = $result->fetch_all(MYSQLI_ASSOC);
        sendJsonResponse(['success' => true, 'data' => $products]);
    }
}

function handleCreateProduct($conn) {
    $input = json_decode(file_get_contents('php://input'), true);

    $sku = sanitize_input($input['sku'] ?? '');
    $product_name = sanitize_input($input['product_name'] ?? '');
    if (empty($sku) || empty($product_name)) {
        sendJsonResponse(['success' => false, 'message' => 'SKU and Product Name are required'], 400);
        return;
    }

    $stmt = $conn->prepare("INSERT INTO products (sku, product_name, description, unit_of_measure, weight, volume, barcode) VALUES (?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param(
        "ssssdds",
        $sku,
        $product_name,
        sanitize_input($input['description'] ?? null),
        sanitize_input($input['unit_of_measure'] ?? null),
        filter_var($input['weight'] ?? null, FILTER_VALIDATE_FLOAT, FILTER_NULL_ON_FAILURE),
        filter_var($input['volume'] ?? null, FILTER_VALIDATE_FLOAT, FILTER_NULL_ON_FAILURE),
        sanitize_input($input['barcode'] ?? null)
    );

    if ($stmt->execute()) {
        sendJsonResponse(['success' => true, 'message' => 'Product created successfully', 'product_id' => $stmt->insert_id], 201);
    } else {
        if ($conn->errno == 1062) {
            sendJsonResponse(['success' => false, 'message' => 'A product with this SKU or Barcode already exists.'], 409);
        } else {
            sendJsonResponse(['success' => false, 'message' => 'Failed to create product', 'error' => $stmt->error], 500);
        }
    }
    $stmt->close();
}

function handleUpdateProduct($conn) {
    $input = json_decode(file_get_contents('php://input'), true);

    $product_id = filter_var($input['product_id'] ?? null, FILTER_VALIDATE_INT);
    if (!$product_id) {
        sendJsonResponse(['success' => false, 'message' => 'Product ID is required for update'], 400);
        return;
    }

    $fields = ['sku', 'product_name', 'description', 'unit_of_measure', 'weight', 'volume', 'barcode'];
    $set_clauses = [];
    $bind_params = [];
    $bind_types = "";

    foreach ($fields as $field) {
        if (array_key_exists($field, $input)) {
            $set_clauses[] = "$field = ?";
            $value = $input[$field];
            $bind_params[] = $value; // Use raw value for bind_param
            if ($field === 'weight' || $field === 'volume') {
                $bind_types .= "d";
            } else {
                $bind_types .= "s";
            }
        }
    }

    if (empty($set_clauses)) {
        sendJsonResponse(['success' => true, 'message' => 'No fields provided to update.'], 200);
        return;
    }

    $sql = "UPDATE products SET " . implode(", ", $set_clauses) . " WHERE product_id = ?";
    $bind_types .= "i";
    $bind_params[] = $product_id;

    $stmt = $conn->prepare($sql);
    $stmt->bind_param($bind_types, ...$bind_params);

    if ($stmt->execute()) {
        if ($stmt->affected_rows > 0) {
            sendJsonResponse(['success' => true, 'message' => 'Product updated successfully.'], 200);
        } else {
            sendJsonResponse(['success' => true, 'message' => 'No changes were made to the product.'], 200);
        }
    } else {
        if ($conn->errno == 1062) {
            sendJsonResponse(['success' => false, 'message' => 'Update failed: This SKU or Barcode is already in use.'], 409);
        } else {
            sendJsonResponse(['success' => false, 'message' => 'Failed to update product.', 'error' => $stmt->error], 500);
        }
    }
    $stmt->close();
}

function handleDeleteProduct($conn) {
    $product_id = filter_var($_GET['id'] ?? null, FILTER_VALIDATE_INT);
    if (!$product_id) {
        sendJsonResponse(['success' => false, 'message' => 'Product ID is required for deletion'], 400);
        return;
    }

    // Check for references in other tables before deleting
    $tables_to_check = ['inventory', 'inbound_items', 'outbound_items'];
    foreach ($tables_to_check as $table) {
        $stmt_check = $conn->prepare("SELECT COUNT(*) as count FROM `$table` WHERE product_id = ?");
        $stmt_check->bind_param("i", $product_id);
        $stmt_check->execute();
        $count = $stmt_check->get_result()->fetch_assoc()['count'];
        $stmt_check->close();
        if ($count > 0) {
            sendJsonResponse(['success' => false, 'message' => "Cannot delete product: It is referenced by existing {$table} records."], 409);
            return;
        }
    }

    $stmt = $conn->prepare("DELETE FROM products WHERE product_id = ?");
    $stmt->bind_param("i", $product_id);
    if ($stmt->execute()) {
        if ($stmt->affected_rows > 0) {
            sendJsonResponse(['success' => true, 'message' => 'Product deleted successfully.'], 200);
        } else {
            sendJsonResponse(['success' => false, 'message' => 'Product not found.'], 404);
        }
    } else {
        sendJsonResponse(['success' => false, 'message' => 'Failed to delete product.', 'error' => $stmt->error], 500);
    }
    $stmt->close();
}
