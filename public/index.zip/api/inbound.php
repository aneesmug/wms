<?php
// api/inbound.php

require_once __DIR__ . '/../config/config.php';

$conn = getDbConnection();
ob_start();

// Authenticate user and ensure a warehouse is selected for ALL inbound operations.
authenticate_user(true, null);
$current_warehouse_id = get_current_warehouse_id();

$method = $_SERVER['REQUEST_METHOD'];
$action = $_GET['action'] ?? '';

// Authorize based on the request method and user's role.
switch ($method) {
    case 'GET':
        // Allow any user with a role to view inbound data.
        authorize_user_role(['viewer', 'operator', 'manager']);
        handleGetInbound($conn, $current_warehouse_id);
        break;
    case 'POST':
        // Restrict all inbound actions (creating, receiving, putaway) to operators and managers.
        authorize_user_role(['operator', 'manager']);
        
        if ($action === 'createReceipt') {
            handleCreateReceipt($conn, $current_warehouse_id);
        } elseif ($action === 'receiveItem') {
            handleReceiveItem($conn, $current_warehouse_id);
        } elseif ($action === 'putawayItem') {
            handlePutawayItem($conn, $current_warehouse_id);
        } else {
            sendJsonResponse(['success' => false, 'message' => 'Invalid POST action'], 400);
        }
        break;
    default:
        sendJsonResponse(['success' => false, 'message' => 'Method Not Allowed'], 405);
        break;
}

// No $conn->close() needed here because sendJsonResponse() includes an exit().

function handleGetInbound($conn, $warehouse_id) {
    if (isset($_GET['receipt_id'])) {
        $receipt_id = filter_var($_GET['receipt_id'], FILTER_VALIDATE_INT);
        if(!$receipt_id) {
            sendJsonResponse(['success' => false, 'message' => 'Invalid Receipt ID.'], 400);
            return;
        }

        // Fetch receipt header
        $stmt = $conn->prepare("SELECT ir.*, u.full_name AS received_by_user FROM inbound_receipts ir LEFT JOIN users u ON ir.received_by = u.user_id WHERE ir.receipt_id = ? AND ir.warehouse_id = ?");
        $stmt->bind_param("ii", $receipt_id, $warehouse_id);
        $stmt->execute();
        $receipt = $stmt->get_result()->fetch_assoc();
        $stmt->close();

        if (!$receipt) {
            sendJsonResponse(['success' => false, 'message' => 'Inbound receipt not found.'], 404);
            return;
        }

        // Fetch receipt items
        $stmt = $conn->prepare("SELECT ii.*, p.sku, p.product_name, p.barcode, wl_received.location_code AS received_location_code, wl_final.location_code AS final_location_code FROM inbound_items ii JOIN products p ON ii.product_id = p.product_id LEFT JOIN warehouse_locations wl_received ON ii.received_location_id = wl_received.location_id LEFT JOIN warehouse_locations wl_final ON ii.final_location_id = wl_final.location_id WHERE ii.receipt_id = ?");
        $stmt->bind_param("i", $receipt_id);
        $stmt->execute();
        $receipt['items'] = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
        $stmt->close();

        sendJsonResponse(['success' => true, 'data' => $receipt]);

    } else {
        // Fetch all receipt summaries for the warehouse
        $stmt = $conn->prepare("SELECT ir.*, w.warehouse_name, s.supplier_name FROM inbound_receipts ir JOIN warehouses w ON ir.warehouse_id = w.warehouse_id LEFT JOIN suppliers s ON ir.supplier_id = s.supplier_id WHERE ir.warehouse_id = ? ORDER BY ir.expected_arrival_date DESC, ir.receipt_id DESC");
        $stmt->bind_param("i", $warehouse_id);
        $stmt->execute();
        $receipts = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
        $stmt->close();
        sendJsonResponse(['success' => true, 'data' => $receipts]);
    }
}

function handleCreateReceipt($conn, $warehouse_id) {
    $input = json_decode(file_get_contents('php://input'), true);

    $receipt_number = sanitize_input($input['receipt_number'] ?? '');
    $supplier_id = filter_var($input['supplier_id'] ?? null, FILTER_VALIDATE_INT);
    $expected_arrival_date = sanitize_input($input['expected_arrival_date'] ?? '');
    $received_by = $_SESSION['user_id'];

    if (empty($receipt_number) || empty($supplier_id) || empty($expected_arrival_date)) {
        sendJsonResponse(['success' => false, 'message' => 'Receipt Number, Supplier, and Expected Arrival Date are required.'], 400);
        return;
    }
    
    // Additional validation can go here (e.g., date format)

    // Using a transaction for safety
    $conn->begin_transaction();
    try {
        // Check for duplicate receipt number in this warehouse
        $stmt = $conn->prepare("SELECT receipt_id FROM inbound_receipts WHERE receipt_number = ? AND warehouse_id = ?");
        $stmt->bind_param("si", $receipt_number, $warehouse_id);
        $stmt->execute();
        if ($stmt->get_result()->num_rows > 0) {
            throw new Exception('A receipt with this number already exists for this warehouse.', 409);
        }
        $stmt->close();

        $stmt = $conn->prepare("INSERT INTO inbound_receipts (warehouse_id, receipt_number, supplier_id, expected_arrival_date, status, received_by) VALUES (?, ?, ?, ?, 'Pending', ?)");
        $stmt->bind_param("isisi", $warehouse_id, $receipt_number, $supplier_id, $expected_arrival_date, $received_by);
        
        if (!$stmt->execute()) {
             throw new Exception('Failed to create receipt in database.');
        }
        $receipt_id = $stmt->insert_id;
        $stmt->close();

        $conn->commit();
        sendJsonResponse(['success' => true, 'message' => 'Receipt created successfully.', 'receipt_id' => $receipt_id], 201);
    } catch (Exception $e) {
        $conn->rollback();
        sendJsonResponse(['success' => false, 'message' => $e->getMessage()], $e->getCode() ?: 500);
    }
}

function handleReceiveItem($conn, $warehouse_id) {
    $input = json_decode(file_get_contents('php://input'), true);
    
    // Validate required fields
    $required = ['receipt_id', 'barcode', 'received_quantity'];
    foreach ($required as $field) {
        if (empty($input[$field])) {
            sendJsonResponse(['success' => false, 'message' => "Missing required field: $field"], 400);
            return;
        }
    }

    $receipt_id = (int)$input['receipt_id'];
    $barcode = trim($input['barcode']);
    $received_quantity = (int)$input['received_quantity'];
    $batch_number = !empty($input['batch_number']) ? trim($input['batch_number']) : null;
    $expiry_date = !empty($input['expiry_date']) ? trim($input['expiry_date']) : null;

    if ($received_quantity <= 0) {
        sendJsonResponse(['success' => false, 'message' => 'Quantity must be positive'], 400);
        return;
    }

    $conn->begin_transaction();

    try {
        // Verify receipt belongs to warehouse
        $stmt = $conn->prepare("SELECT receipt_id FROM inbound_receipts WHERE receipt_id = ? AND warehouse_id = ?");
        $stmt->bind_param("ii", $receipt_id, $warehouse_id);
        $stmt->execute();
        
        if (!$stmt->get_result()->fetch_assoc()) {
            throw new Exception("Receipt not found in warehouse");
        }
        $stmt->close();

        // Get product ID
        $stmt = $conn->prepare("SELECT product_id FROM products WHERE barcode = ?");
        $stmt->bind_param("s", $barcode);
        $stmt->execute();
        $product = $stmt->get_result()->fetch_assoc();
        $stmt->close();

        if (!$product) {
            throw new Exception("Product not found");
        }
        $product_id = $product['product_id'];

        // Generate batch number if not provided by user
        if (!$batch_number) {
            $batch_number = 'INB-' . date('Ymd-His') . '-' . bin2hex(random_bytes(2));
        }

        // Check for existing item with same batch in inbound_items
        $stmt = $conn->prepare("
            SELECT inbound_item_id, expected_quantity, received_quantity 
            FROM inbound_items 
            WHERE receipt_id = ? AND product_id = ? AND (batch_number = ? OR (batch_number IS NULL AND ? IS NULL))
        ");
        $stmt->bind_param("iiss", $receipt_id, $product_id, $batch_number, $batch_number);
        $stmt->execute();
        $existing_item = $stmt->get_result()->fetch_assoc();
        $stmt->close();

        // Get receiving location (assuming a default receiving location for the warehouse)
        $received_location_id = null;
        $stmt_rec_loc = $conn->prepare("SELECT location_id FROM warehouse_locations WHERE warehouse_id = ? AND location_type = 'receiving_bay' LIMIT 1");
        $stmt_rec_loc->bind_param("i", $warehouse_id);
        $stmt_rec_loc->execute();
        $rec_loc_data = $stmt_rec_loc->get_result()->fetch_assoc();
        $stmt_rec_loc->close();
        if ($rec_loc_data) {
            $received_location_id = $rec_loc_data['location_id'];
        }


        if ($existing_item) {
            // Update existing item
            $new_quantity = $existing_item['received_quantity'] + $received_quantity;
            $status = ($new_quantity >= $existing_item['expected_quantity']) ? 'Received' : 'Partially Received';
            
            $stmt = $conn->prepare("
                UPDATE inbound_items 
                SET received_quantity = ?, status = ?, updated_at = NOW() 
                WHERE inbound_item_id = ?
            ");
            $stmt->bind_param("isi", $new_quantity, $status, $existing_item['inbound_item_id']);
        } else {
            // Create new item
            $status = 'Received';
            $stmt = $conn->prepare("
                INSERT INTO inbound_items (
                    receipt_id, product_id, expected_quantity, received_quantity,
                    batch_number, expiry_date, status, received_location_id
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            ");
            $stmt->bind_param(
                "iiissssi", 
                $receipt_id, $product_id, $received_quantity, $received_quantity, 
                $batch_number, $expiry_date, $status, $received_location_id
            );
        }

        if (!$stmt->execute()) {
            throw new Exception("Failed to update item: " . $stmt->error);
        }
        $stmt->close();

        // Update receipt status
        updateReceiptStatus($conn, $receipt_id);

        $conn->commit();
        sendJsonResponse([
            'success' => true,
            'message' => 'Item received',
            'generated_batch_number' => $batch_number
        ]);
    } catch (Exception $e) {
        $conn->rollback();
        sendJsonResponse([
            'success' => false,
            'message' => $e->getMessage()
        ], 400);
    }
}

function handlePutawayItem($conn, $warehouse_id) {
    $input = json_decode(file_get_contents('php://input'), true);
    
    // Validate required fields
    $required = ['receipt_id', 'barcode', 'location_barcode', 'putaway_quantity'];
    foreach ($required as $field) {
        if (empty($input[$field])) {
            sendJsonResponse(['success' => false, 'message' => "Missing required field: $field"], 400);
            return;
        }
    }

    $receipt_id = (int)$input['receipt_id'];
    $barcode = trim($input['barcode']);
    $location_barcode = trim($input['location_barcode']);
    $putaway_quantity = (int)$input['putaway_quantity'];
    // $batch_number is fetched from inbound_items, not strictly required from input for finding item
    $input_batch_number = !empty($input['batch_number']) ? trim($input['batch_number']) : null;


    if ($putaway_quantity <= 0) {
        sendJsonResponse(['success' => false, 'message' => 'Quantity must be positive'], 400);
        return;
    }
    
    $conn->begin_transaction();

    try {
        // Verify receipt belongs to warehouse
        $stmt = $conn->prepare("SELECT receipt_id FROM inbound_receipts WHERE receipt_id = ? AND warehouse_id = ?");
        $stmt->bind_param("ii", $receipt_id, $warehouse_id);
        $stmt->execute();
        
        if (!$stmt->get_result()->fetch_assoc()) {
            throw new Exception("Receipt not found in warehouse");
        }
        $stmt->close();

        // Get product ID
        $stmt = $conn->prepare("SELECT product_id FROM products WHERE barcode = ?");
        $stmt->bind_param("s", $barcode);
        $stmt->execute();
        $product = $stmt->get_result()->fetch_assoc();
        $stmt->close();

        if (!$product) {
            throw new Exception("Product not found");
        }
        $product_id = $product['product_id'];

        // Get and verify location (ensuring it's in the current warehouse)
        $stmt = $conn->prepare("
            SELECT location_id, max_capacity_units FROM warehouse_locations 
            WHERE location_code = ? AND warehouse_id = ?
        ");
        $stmt->bind_param("si", $location_barcode, $warehouse_id);
        $stmt->execute();
        $location_data = $stmt->get_result()->fetch_assoc();
        $stmt->close();

        if (!$location_data) {
            throw new Exception("Location not found in warehouse");
        }
        $final_location_id = $location_data['location_id'];
        $max_capacity_units = $location_data['max_capacity_units']; // Get max capacity

        // --- CAPACITY CHECK ---
        if ($max_capacity_units !== null) { // Only perform check if a max capacity is defined
            $stmt_occupied = $conn->prepare("SELECT COALESCE(SUM(quantity), 0) AS occupied FROM inventory WHERE location_id = ? AND warehouse_id = ?");
            $stmt_occupied->bind_param("ii", $final_location_id, $warehouse_id);
            $stmt_occupied->execute();
            $occupied_data = $stmt_occupied->get_result()->fetch_assoc();
            $stmt_occupied->close();
            $current_occupied = $occupied_data['occupied'];

            if (($current_occupied + $putaway_quantity) > $max_capacity_units) {
                throw new Exception("Location '{$location_barcode}' has insufficient capacity. Available: " . ($max_capacity_units - $current_occupied) . " units. You tried to add {$putaway_quantity} units.");
            }
        }
        // --- END CAPACITY CHECK ---


        // Find item to putaway (match by receipt, product, and dynamically chosen batch or explicit batch)
        $sql_find_item = "
            SELECT inbound_item_id, received_quantity, putaway_quantity, batch_number, expiry_date
            FROM inbound_items 
            WHERE receipt_id = ? AND product_id = ? 
            AND received_quantity > putaway_quantity
        ";
        $find_item_params = [$receipt_id, $product_id];
        $find_item_types = "ii";

        if (!empty($input_batch_number)) { // If user provided a batch, match that specific batch
            $sql_find_item .= " AND (batch_number = ? OR (batch_number IS NULL AND ? IS NULL))";
            $find_item_params[] = $input_batch_number;
            $find_item_params[] = $input_batch_number; // For NULL check in batch_number
            $find_item_types .= "ss";
        } else {
            // If batch is NOT provided by user, select an available batch for putaway.
            // Priority: Oldest expiry date, then oldest batch number (FIFO/FEFO)
            $sql_find_item .= " ORDER BY expiry_date ASC, batch_number ASC LIMIT 1";
        }

        $stmt = $conn->prepare($sql_find_item);
        if (!$stmt) {
             throw new Exception("Prepare find item for putaway failed: " . $conn->error);
        }
        call_user_func_array([$stmt, 'bind_param'], array_merge([$find_item_types], $find_item_params));
        $stmt->execute();
        $item = $stmt->get_result()->fetch_assoc();
        $stmt->close();

        if (!$item) {
            throw new Exception("No received items available for putaway matching product and batch (if provided) in this receipt.");
        }

        $remaining_to_putaway_in_item = $item['received_quantity'] - $item['putaway_quantity'];
        if ($putaway_quantity > $remaining_to_putaway_in_item) {
            throw new Exception("Putaway quantity exceeds remaining received quantity for this item.");
        }

        // Use the batch_number and expiry_date from the FOUND inbound_item record for consistency in inventory
        $effective_batch_for_inventory = $item['batch_number'];
        $effective_expiry_for_inventory = $item['expiry_date'];


        // Update inbound item
        $new_putaway = $item['putaway_quantity'] + $putaway_quantity;
        $status = ($new_putaway >= $item['received_quantity']) ? 'Putaway' : 'Partially Putaway';

        $stmt = $conn->prepare("
            UPDATE inbound_items 
            SET putaway_quantity = ?, status = ?, final_location_id = ?, updated_at = NOW()
            WHERE inbound_item_id = ?
        ");
        $stmt->bind_param("isii", $new_putaway, $status, $final_location_id, $item['inbound_item_id']);
        
        if (!$stmt->execute()) {
            throw new Exception("Failed to update item: " . $stmt->error);
        }
        $stmt->close();

        // Update inventory (add to final location, using item's batch/expiry)
        $stmt = $conn->prepare("
            INSERT INTO inventory (
                warehouse_id, product_id, location_id, quantity, batch_number, expiry_date
            ) VALUES (?, ?, ?, ?, ?, ?)
            ON DUPLICATE KEY UPDATE 
                quantity = quantity + VALUES(quantity),
                last_moved_at = NOW()
        ");
        $stmt->bind_param(
            "iiiiss", 
            $warehouse_id, $product_id, $final_location_id,
            $putaway_quantity, $effective_batch_for_inventory, $effective_expiry_for_inventory
        );
        
        if (!$stmt->execute()) {
            throw new Exception("Failed to update inventory: " . $conn->error);
        }
        $stmt->close();

        // Update receipt status
        updateReceiptStatus($conn, $receipt_id);

        $conn->commit();
        sendJsonResponse(['success' => true, 'message' => 'Item putaway successfully']);
    } catch (Exception $e) {
        $conn->rollback();
        // Log the error for server-side debugging
        error_log("Putaway Error: " . $e->getMessage() . " | SQL Error: " . ($conn->error ?? 'N/A'));
        sendJsonResponse([
            'success' => false, 
            'message' => $e->getMessage() . " (Refer to server logs for details).",
            'error_details' => $conn->error ?? null
        ], 400);
    }
}

function updateReceiptStatus($conn, $receipt_id) {
    // Get receipt summary
    $stmt = $conn->prepare("
        SELECT 
            COUNT(inbound_item_id) AS total_items,
            SUM(CASE WHEN status = 'Received' OR status = 'Putaway' OR status = 'Partially Received' OR status = 'Partially Putaway' THEN 1 ELSE 0 END) AS received_lines,
            SUM(CASE WHEN status = 'Putaway' OR status = 'Partially Putaway' THEN 1 ELSE 0 END) AS putaway_lines,
            SUM(expected_quantity) AS total_expected,
            SUM(received_quantity) AS total_received,
            SUM(putaway_quantity) AS total_putaway
        FROM inbound_items
        WHERE receipt_id = ?
    ");
    $stmt->bind_param("i", $receipt_id);
    $stmt->execute();
    $summary = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    // Determine new status
    $new_status = 'Pending';
    $now = date('Y-m-d H:i:s');

    if ($summary['total_items'] == 0) {
        $new_status = 'Pending';
    } elseif ($summary['total_putaway'] >= $summary['total_received'] && $summary['total_received'] > 0) {
        $new_status = 'Completed';
    } elseif ($summary['total_received'] > 0 && $summary['total_putaway'] > 0) {
        $new_status = 'Partially Putaway';
    } elseif ($summary['total_received'] >= $summary['total_expected'] && $summary['total_expected'] > 0) {
        $new_status = 'Received';
    } elseif ($summary['total_received'] > 0) {
        $new_status = 'Partially Received';
    }
    
    // Update receipt
    $stmt = $conn->prepare("
        UPDATE inbound_receipts 
        SET status = ?,
            actual_arrival_date = IF(? = 'Received' AND actual_arrival_date IS NULL, ?, actual_arrival_date),
            updated_at = NOW()
        WHERE receipt_id = ?
    ");
    $arrival_date = ($new_status === 'Received') ? $now : null;
    $stmt->bind_param("sssi", $new_status, $new_status, $now, $receipt_id);
    $stmt->execute();
    $stmt->close();
}