<?php
// api/auth.php

// CRITICAL: Ensure NO whitespace, BOM, or any characters before this opening PHP tag.

require_once __DIR__ . '/../config/config.php';

// Initialize $conn immediately after including config.php
$conn = getDbConnection();

// Start Output Buffering at the very beginning of the script.
ob_start();

$action = $_GET['action'] ?? ''; // Get the action from the query string

switch ($action) {
    case 'login':
        handleLogin($conn);
        break;
    case 'logout':
        handleLogout();
        break;
    case 'check_auth':
        checkAuthentication();
        break;
    case 'set_warehouse':
        handleSetWarehouse($conn);
        break;
    default:
        sendJsonResponse(['message' => 'Invalid action'], 400);
        break;
}

function handleLogin($conn) {
    $input = json_decode(file_get_contents('php://input'), true);
    $username = sanitize_input($input['username'] ?? '');
    $password = $input['password'] ?? '';

    if (empty($username) || empty($password)) {
        sendJsonResponse(['message' => 'Username and password are required'], 400);
    }

    // UPDATED QUERY: Select is_global_admin, remove old 'role' field.
    $stmt = $conn->prepare("SELECT user_id, username, password_hash, is_global_admin FROM users WHERE username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();
    $user = $result->fetch_assoc();
    $stmt->close();

    if ($user && password_verify($password, $user['password_hash'])) {
        // Authentication successful
        $_SESSION['user_id'] = $user['user_id'];
        $_SESSION['username'] = $user['username'];
        // Store is_global_admin status.
        $_SESSION['is_global_admin'] = (bool)$user['is_global_admin'];
        
        // Clear any previous warehouse selection on new login.
        unset_current_warehouse();

        sendJsonResponse([
            'success' => true, 
            'message' => 'Login successful', 
            'user' => [
                'username' => $user['username'], 
                'is_global_admin' => (bool)$user['is_global_admin']
            ]
        ]);
    } else {
        // Authentication failed
        sendJsonResponse(['success' => false, 'message' => 'Invalid username or password'], 401);
    }
}

function handleLogout() {
    // Unset all session variables
    $_SESSION = [];
    // Destroy the session
    session_destroy();
    sendJsonResponse(['success' => true, 'message' => 'Logged out successfully']);
}

function checkAuthentication() {
    if (isset($_SESSION['user_id'])) {
        sendJsonResponse([
            'authenticated' => true, 
            'user' => [
                'username' => $_SESSION['username'], 
                'is_global_admin' => $_SESSION['is_global_admin'] ?? false
            ], 
            'current_warehouse_id' => get_current_warehouse_id(), 
            'current_warehouse_name' => get_current_warehouse_name(),
            'current_warehouse_role' => get_current_warehouse_role() // NEW: Return current role
        ]);
    } else {
        sendJsonResponse(['authenticated' => false]);
    }
}

function handleSetWarehouse($conn) {
    // First, ensure user is logged in.
    if (!isset($_SESSION['user_id'])) {
        sendJsonResponse(['success' => false, 'message' => 'Unauthorized: Please log in.'], 401);
        return;
    }

    $input = json_decode(file_get_contents('php://input'), true);
    $warehouse_id = filter_var($input['warehouse_id'] ?? null, FILTER_VALIDATE_INT);
    
    if (!$warehouse_id) {
        sendJsonResponse(['success' => false, 'message' => 'Invalid warehouse ID provided.'], 400);
        return;
    }

    // Step 1: Verify warehouse exists and get its name (security check).
    $stmt = $conn->prepare("SELECT warehouse_name FROM warehouses WHERE warehouse_id = ? AND is_active = TRUE");
    $stmt->bind_param("i", $warehouse_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $warehouse = $result->fetch_assoc();
    $stmt->close();

    if (!$warehouse) {
        sendJsonResponse(['success' => false, 'message' => 'Warehouse not found or is inactive.'], 404);
        return;
    }
    $warehouse_name = $warehouse['warehouse_name'];
    $user_id = $_SESSION['user_id'];
    $user_role_for_warehouse = null;

    // Step 2: Determine user's role for this warehouse.
    // If the user is a global admin, they get the 'manager' role implicitly.
    if (isset($_SESSION['is_global_admin']) && $_SESSION['is_global_admin'] === true) {
        $user_role_for_warehouse = 'manager'; // Assign highest role.
    } else {
        // Otherwise, look up their specific role for this warehouse in the junction table.
        $stmt = $conn->prepare("SELECT role FROM user_warehouse_roles WHERE user_id = ? AND warehouse_id = ?");
        $stmt->bind_param("ii", $user_id, $warehouse_id);
        $stmt->execute();
        $result = $stmt->get_result();
        $role_info = $result->fetch_assoc();
        $stmt->close();

        if ($role_info) {
            $user_role_for_warehouse = $role_info['role'];
        }
    }

    // Step 3: Check if a role was found. If not, the user has no access.
    if ($user_role_for_warehouse === null) {
        sendJsonResponse(['success' => false, 'message' => 'You do not have permission to access this warehouse.'], 403);
        return;
    }
    
    // Step 4: Set the warehouse and role in the server-side session.
    set_current_warehouse($warehouse_id, $warehouse_name, $user_role_for_warehouse);
    
    // Step 5: Respond to the client with success and the assigned role.
    sendJsonResponse([
        'success' => true, 
        'message' => 'Warehouse set successfully.',
        'role' => $user_role_for_warehouse
    ]);
}
