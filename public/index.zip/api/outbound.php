<?php
// api/outbound.php

require_once __DIR__ . '/../config/config.php';

$conn = getDbConnection();
ob_start();

// Authenticate user and ensure a warehouse is selected for ALL outbound operations.
authenticate_user(true, null);
$current_warehouse_id = get_current_warehouse_id();

$method = $_SERVER['REQUEST_METHOD'];
$action = $_GET['action'] ?? '';

// Authorize based on the request method and user's role.
switch ($method) {
    case 'GET':
        // Allow any user with a role to view outbound data.
        authorize_user_role(['viewer', 'operator', 'manager']);
        handleGetOutbound($conn, $current_warehouse_id);
        break;
    case 'POST':
        // Restrict all outbound actions (creating, picking, shipping) to operators and managers.
        authorize_user_role(['operator', 'manager']);
        
        if ($action === 'createOrder') {
            handleCreateOutboundOrder($conn, $current_warehouse_id);
        } elseif ($action === 'addItem') {
            handleAddItemToOrder($conn, $current_warehouse_id);
        } elseif ($action === 'pickItem') {
            handlePickItem($conn, $current_warehouse_id);
        } elseif ($action === 'shipOrder') {
            handleShipOrder($conn, $current_warehouse_id);
        } else {
            sendJsonResponse(['success' => false, 'message' => 'Invalid POST action'], 400);
        }
        break;
    default:
        sendJsonResponse(['success' => false, 'message' => 'Method Not Allowed'], 405);
        break;
}

function handleGetOutbound($conn, $warehouse_id) {
    if (isset($_GET['order_id'])) {
        $order_id = filter_var($_GET['order_id'], FILTER_VALIDATE_INT);
        if(!$order_id) {
            sendJsonResponse(['success' => false, 'message' => 'Invalid Order ID.'], 400);
            return;
        }

        // Fetch order header
        $stmt = $conn->prepare("SELECT oo.*, c.customer_name, w.warehouse_name FROM outbound_orders oo JOIN customers c ON oo.customer_id = c.customer_id JOIN warehouses w ON oo.warehouse_id = w.warehouse_id WHERE oo.order_id = ? AND oo.warehouse_id = ?");
        $stmt->bind_param("ii", $order_id, $warehouse_id);
        $stmt->execute();
        $order = $stmt->get_result()->fetch_assoc();
        $stmt->close();

        if (!$order) {
            sendJsonResponse(['success' => false, 'message' => 'Outbound order not found.'], 404);
            return;
        }

        // Fetch order items
        $stmt = $conn->prepare("SELECT oi.*, p.sku, p.product_name, p.barcode, wl.location_code AS picked_from_location_code FROM outbound_items oi JOIN products p ON oi.product_id = p.product_id LEFT JOIN warehouse_locations wl ON oi.picked_from_location_id = wl.location_id WHERE oi.order_id = ?");
        $stmt->bind_param("i", $order_id);
        $stmt->execute();
        $order['items'] = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
        $stmt->close();

        sendJsonResponse(['success' => true, 'data' => $order]);

    } else {
        // Fetch all order summaries
        $stmt = $conn->prepare("SELECT oo.*, c.customer_name, w.warehouse_name FROM outbound_orders oo JOIN customers c ON oo.customer_id = c.customer_id JOIN warehouses w ON oo.warehouse_id = w.warehouse_id WHERE oo.warehouse_id = ? ORDER BY oo.order_date DESC");
        $stmt->bind_param("i", $warehouse_id);
        $stmt->execute();
        $orders = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
        $stmt->close();
        sendJsonResponse(['success' => true, 'data' => $orders]);
    }
}

function handleCreateOutboundOrder($conn, $warehouse_id) {
    $input = json_decode(file_get_contents('php://input'), true);

    $order_number = sanitize_input($input['order_number'] ?? '');
    $customer_id = filter_var($input['customer_id'] ?? null, FILTER_VALIDATE_INT);
    $required_ship_date = sanitize_input($input['required_ship_date'] ?? '');
    $user_id = $_SESSION['user_id'];

    if (empty($order_number) || empty($customer_id) || empty($required_ship_date)) {
        sendJsonResponse(['success' => false, 'message' => 'Order Number, Customer, and Required Ship Date are required.'], 400);
        return;
    }
    
    $conn->begin_transaction();
    try {
        // Check for duplicate order number
        $stmt = $conn->prepare("SELECT order_id FROM outbound_orders WHERE order_number = ? AND warehouse_id = ?");
        $stmt->bind_param("si", $order_number, $warehouse_id);
        $stmt->execute();
        if ($stmt->get_result()->num_rows > 0) {
            throw new Exception('An order with this number already exists for this warehouse.', 409);
        }
        $stmt->close();

        $stmt = $conn->prepare("INSERT INTO outbound_orders (warehouse_id, order_number, customer_id, required_ship_date, status, picked_by) VALUES (?, ?, ?, ?, 'New', ?)");
        $stmt->bind_param("isisi", $warehouse_id, $order_number, $customer_id, $required_ship_date, $user_id);
        
        if (!$stmt->execute()) {
             throw new Exception('Failed to create outbound order in database.');
        }
        $order_id = $stmt->insert_id;
        $stmt->close();

        $conn->commit();
        sendJsonResponse(['success' => true, 'message' => 'Outbound order created successfully.', 'order_id' => $order_id], 201);
    } catch (Exception $e) {
        $conn->rollback();
        sendJsonResponse(['success' => false, 'message' => $e->getMessage()], $e->getCode() ?: 500);
    }
}

function handleAddItemToOrder($conn, $warehouse_id) { // Pass warehouse_id
    $input = json_decode(file_get_contents('php://input'), true);

    $order_id = (int)$input['order_id'];
    $product_barcode = trim($input['product_barcode'] ?? '');
    $ordered_quantity = filter_var($input['ordered_quantity'] ?? 0, FILTER_VALIDATE_INT);

    if (empty($order_id) || empty($product_barcode) || $ordered_quantity <= 0) {
        sendJsonResponse(['success' => false, 'message' => 'Order ID, Product Barcode, and Quantity are required.'], 400);
        return;
    }

    $conn->begin_transaction();

    try {
        // Verify order belongs to current warehouse
        $stmt = $conn->prepare("SELECT order_id FROM outbound_orders WHERE order_id = ? AND warehouse_id = ?");
        $stmt->bind_param("ii", $order_id, $warehouse_id);
        $stmt->execute();
        if (!$stmt->get_result()->fetch_assoc()) {
            throw new Exception("Order not found or does not belong to selected warehouse.");
        }
        $stmt->close();

        // Get product ID from barcode
        $stmt = $conn->prepare("SELECT product_id FROM products WHERE barcode = ?");
        $stmt->bind_param("s", $product_barcode);
        $stmt->execute();
        $product_data = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        if (!$product_data) {
            throw new Exception("Product not found with the provided barcode.");
        }
        $product_id = $product_data['product_id'];

        // Check if item already exists in order
        $stmt = $conn->prepare("SELECT outbound_item_id, ordered_quantity FROM outbound_items WHERE order_id = ? AND product_id = ?");
        $stmt->bind_param("ii", $order_id, $product_id);
        $stmt->execute();
        $existing_item = $stmt->get_result()->fetch_assoc();
        $stmt->close();

        if ($existing_item) {
            // Update existing item's quantity
            $new_quantity = $existing_item['ordered_quantity'] + $ordered_quantity;
            $stmt = $conn->prepare("UPDATE outbound_items SET ordered_quantity = ? WHERE outbound_item_id = ?");
            $stmt->bind_param("ii", $new_quantity, $existing_item['outbound_item_id']);
        } else {
            // Insert new item
            $stmt = $conn->prepare("INSERT INTO outbound_items (order_id, product_id, ordered_quantity) VALUES (?, ?, ?)");
            $stmt->bind_param("iii", $order_id, $product_id, $ordered_quantity);
        }

        if (!$stmt->execute()) {
            throw new Exception("Failed to add/update item in order: " . $stmt->error);
        }
        $stmt->close();

        // Update order status if it's 'New'
        $stmt_update_order = $conn->prepare("UPDATE outbound_orders SET status = 'Pending Pick' WHERE order_id = ? AND status = 'New'");
        $stmt_update_order->bind_param("i", $order_id);
        $stmt_update_order->execute();
        $stmt_update_order->close();

        $conn->commit();
        sendJsonResponse(['success' => true, 'message' => 'Item added/updated in order.']);
    } catch (Exception $e) {
        $conn->rollback();
        sendJsonResponse(['success' => false, 'message' => $e->getMessage()], 400);
    }
}


function handlePickItem($conn, $warehouse_id) { // Pass warehouse_id
    $input = json_decode(file_get_contents('php://input'), true);

    $order_id = (int)$input['order_id'];
    $product_barcode = trim($input['product_barcode'] ?? '');
    $location_id = filter_var($input['location_id'] ?? null, FILTER_VALIDATE_INT); // NOW expecting location_ID directly
    $picked_quantity = filter_var($input['picked_quantity'] ?? 0, FILTER_VALIDATE_INT);
    $user_id = $_SESSION['user_id'] ?? null; // Get current user ID from session
    $batch_number = !empty($input['batch_number']) ? trim($input['batch_number']) : null; // Optional: specific batch to pick

    // Validate incoming location_id
    if (empty($order_id) || empty($product_barcode) || empty($location_id) || $picked_quantity <= 0 || !$user_id) {
        sendJsonResponse(['success' => false, 'message' => 'Order ID, Product Barcode, Location ID, Picked Quantity, and User ID are required.'], 400);
        return;
    }

    $conn->begin_transaction();

    try {
        // Verify order belongs to current warehouse
        $stmt = $conn->prepare("SELECT order_id FROM outbound_orders WHERE order_id = ? AND warehouse_id = ?");
        $stmt->bind_param("ii", $order_id, $warehouse_id);
        $stmt->execute();
        if (!$stmt->get_result()->fetch_assoc()) {
            throw new Exception("Order not found or does not belong to selected warehouse.");
        }
        $stmt->close();

        // 1. Get product_id from barcode
        $stmt = $conn->prepare("SELECT product_id FROM products WHERE barcode = ?");
        $stmt->bind_param("s", $product_barcode);
        $stmt->execute();
        $product_data = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        if (!$product_data) {
            throw new Exception("Product not found with barcode: " . $product_barcode);
        }
        $product_id = $product_data['product_id'];

        // 2. Verify location_id belongs to the current warehouse and get its code
        $stmt = $conn->prepare("SELECT location_code FROM warehouse_locations WHERE location_id = ? AND warehouse_id = ?");
        $stmt->bind_param("ii", $location_id, $warehouse_id);
        $stmt->execute();
        $location_data = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        if (!$location_data) {
            throw new Exception("Location not found or does not belong to selected warehouse.");
        }
        $location_code = $location_data['location_code']; // We might still need the code for logs/display

        // 3. Check inventory at location for the specific product and optionally batch
        $inventory_query = "SELECT quantity, batch_number, expiry_date FROM inventory WHERE warehouse_id = ? AND product_id = ? AND location_id = ?";
        $inventory_types = "iii";
        $inventory_params = [$warehouse_id, $product_id, $location_id]; // Use location_id directly here

        if (!empty($batch_number)) {
            $inventory_query .= " AND batch_number = ?";
            $inventory_types .= "s";
            $inventory_params[] = $batch_number;
        } else {
            $inventory_query .= " ORDER BY expiry_date ASC, batch_number ASC LIMIT 1";
        }

        $stmt_check_inv = $conn->prepare($inventory_query);
        call_user_func_array([$stmt_check_inv, 'bind_param'], array_merge([$inventory_types], $inventory_params));
        $stmt_check_inv->execute();
        $inventory_item = $stmt_check_inv->get_result()->fetch_assoc();
        $stmt_check_inv->close();

        if (!$inventory_item || $inventory_item['quantity'] < $picked_quantity) {
            throw new Exception("Insufficient stock at location for picking. Available: " . ($inventory_item['quantity'] ?? 0));
        }
        $effective_batch_picked = $inventory_item['batch_number'];
        $effective_expiry_picked = $inventory_item['expiry_date'];

        // 4. Update inventory (decrement quantity for the specific batch)
        $stmt = $conn->prepare("UPDATE inventory SET quantity = quantity - ? WHERE warehouse_id = ? AND product_id = ? AND location_id = ? AND (batch_number = ? OR (batch_number IS NULL AND ? IS NULL))");
        $stmt->bind_param("iiiiss", $picked_quantity, $warehouse_id, $product_id, $location_id, $effective_batch_picked, $effective_batch_picked);
        $stmt->execute();
        if ($stmt->affected_rows === 0) {
            throw new Exception("Failed to update inventory quantity during picking.");
        }
        $stmt->close();

        // Delete inventory lines with 0 quantity
        $stmt_delete_zero = $conn->prepare("DELETE FROM inventory WHERE warehouse_id = ? AND product_id = ? AND location_id = ? AND (batch_number = ? OR (batch_number IS NULL AND ? IS NULL)) AND quantity <= 0");
        $stmt_delete_zero->bind_param("iiiss", $warehouse_id, $product_id, $location_id, $effective_batch_picked, $effective_batch_picked);
        $stmt_delete_zero->execute();
        $stmt_delete_zero->close();


        // 5. Update outbound_items (increment picked_quantity)
        $stmt = $conn->prepare("SELECT outbound_item_id, picked_quantity, ordered_quantity FROM outbound_items WHERE order_id = ? AND product_id = ?");
        $stmt->bind_param("ii", $order_id, $product_id);
        $stmt->execute();
        $outbound_item = $stmt->get_result()->fetch_assoc();
        $stmt->close();

        if ($outbound_item) {
            $new_picked_quantity = $outbound_item['picked_quantity'] + $picked_quantity;
            $stmt = $conn->prepare("UPDATE outbound_items SET picked_quantity = ?, picked_from_location_id = ?, batch_number = ?, updated_at = NOW() WHERE outbound_item_id = ?");
            $stmt->bind_param("iisi", $new_picked_quantity, $location_id, $effective_batch_picked, $outbound_item['outbound_item_id']);
        } else {
            $status_new_item = 'Picked';
            $stmt = $conn->prepare("INSERT INTO outbound_items (order_id, product_id, ordered_quantity, picked_quantity, picked_from_location_id, batch_number, status) VALUES (?, ?, ?, ?, ?, ?, ?)");
            $ordered_qty_placeholder = 0;
            $stmt->bind_param("iiiiiss", $order_id, $product_id, $ordered_qty_placeholder, $picked_quantity, $location_id, $effective_batch_picked, $status_new_item);
        }
        $stmt->execute();
        if ($stmt->affected_rows === 0) {
            throw new Exception("Failed to update outbound item picked quantity.");
        }
        $stmt->close();

        // 6. Update outbound_orders status
        updateOutboundOrderStatus($conn, $order_id, $user_id);

        $conn->commit();
        sendJsonResponse(['success' => true, 'message' => 'Item picked successfully and inventory updated.']);

    } catch (Exception $e) {
        $conn->rollback();
        error_log("Outbound picking error: " . $e->getMessage());
        sendJsonResponse(['success' => false, 'message' => $e->getMessage()], 400);
    }
}

function handleShipOrder($conn, $warehouse_id) { // Pass warehouse_id
    $input = json_decode(file_get_contents('php://input'), true);

    $order_id = (int)$input['order_id'];
    $shipped_by_user_id = $_SESSION['user_id'] ?? null;

    if (empty($order_id) || !$shipped_by_user_id) {
        sendJsonResponse(['success' => false, 'message' => 'Order ID and User ID are required for shipping.'], 400);
        return;
    }

    $conn->begin_transaction();

    try {
        // Verify order belongs to current warehouse and get current status
        $stmt = $conn->prepare("SELECT order_id, status FROM outbound_orders WHERE order_id = ? AND warehouse_id = ?");
        $stmt->bind_param("ii", $order_id, $warehouse_id);
        $stmt->execute();
        $order_data = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        if (!$order_data) {
            throw new Exception("Order not found or does not belong to selected warehouse.");
        }

        // Check if the order is fully picked or partially picked before allowing ship
        if ($order_data['status'] !== 'Picked' && $order_data['status'] !== 'Partially Picked') {
             throw new Exception("Order must be picked (or partially picked) before it can be shipped. Current status: " . $order_data['status']);
        }


        // Update outbound_items to 'Shipped' and set shipped_quantity (only for items that were picked)
        $stmt = $conn->prepare("UPDATE outbound_items SET shipped_quantity = picked_quantity, status = 'Shipped', updated_at = NOW() WHERE order_id = ? AND picked_quantity > 0");
        $stmt->bind_param("i", $order_id);
        $stmt->execute();
        $stmt->close();

        // Update outbound_orders status to 'Shipped' and record actual ship date/user
        $stmt = $conn->prepare("UPDATE outbound_orders SET status = 'Shipped', actual_ship_date = NOW(), shipped_by = ? WHERE order_id = ?");
        $stmt->bind_param("ii", $shipped_by_user_id, $order_id);
        $stmt->execute();
        $stmt->close();

        $conn->commit();
        sendJsonResponse(['success' => true, 'message' => 'Order successfully shipped.']);

    } catch (Exception $e) {
        $conn->rollback();
        error_log("Outbound shipping error: " . $e->getMessage());
        sendJsonResponse(['success' => false, 'message' => $e->getMessage()], 400);
    }
}

/**
 * Helper function to update the outbound order status based on its items' picking status.
 */
function updateOutboundOrderStatus($conn, $order_id, $user_id) {
    // Check if order is fully picked
    $stmt = $conn->prepare("
        SELECT 
            SUM(ordered_quantity) AS total_ordered, 
            SUM(picked_quantity) AS total_picked 
        FROM outbound_items 
        WHERE order_id = ?
    ");
    $stmt->bind_param("i", $order_id);
    $stmt->execute();
    $order_sums = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    $new_order_status = 'Pending Pick'; // Default
    if ($order_sums['total_picked'] >= $order_sums['total_ordered']) {
        $new_order_status = 'Picked';
    } else if ($order_sums['total_picked'] > 0) {
        $new_order_status = 'Partially Picked';
    }

    $stmt = $conn->prepare("UPDATE outbound_orders SET status = ?, picked_by = ? WHERE order_id = ?");
    $stmt->bind_param("sii", $new_order_status, $user_id, $order_id);
    $stmt->execute();
    $stmt->close();
}