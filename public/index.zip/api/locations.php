<?php
// api/locations.php

require_once __DIR__ . '/../config/config.php';

$conn = getDbConnection();

ob_start();

// Step 1: Authenticate user and ensure a warehouse is selected.
// Role-specific checks will be done for each action (method).
authenticate_user(true, null); 

$current_warehouse_id = get_current_warehouse_id();

$method = $_SERVER['REQUEST_METHOD'];

// Step 2: Authorize based on method, then handle the request.
switch ($method) {
    case 'GET':
        // Allow users with any assigned role to view locations.
        authorize_user_role(['viewer', 'operator', 'manager']);
        handleGetLocations($conn, $current_warehouse_id);
        break;
    case 'POST':
        // Only allow operators and managers to create new locations.
        authorize_user_role(['operator', 'manager']);
        handleCreateLocation($conn, $current_warehouse_id);
        break;
    case 'PUT':
        // Only allow operators and managers to update locations.
        authorize_user_role(['operator', 'manager']);
        handleUpdateLocation($conn, $current_warehouse_id);
        break;
    case 'DELETE':
        // Restrict deletion to managers only.
        authorize_user_role(['manager']);
        handleDeleteLocation($conn, $current_warehouse_id);
        break;
    default:
        sendJsonResponse(['success' => false, 'message' => 'Method Not Allowed'], 405);
        break;
}


function handleGetLocations($conn, $warehouse_id) {
    if (isset($_GET['id'])) {
        $location_id = filter_var($_GET['id'], FILTER_VALIDATE_INT);
        if (!$location_id) {
            sendJsonResponse(['success' => false, 'message' => 'Invalid Location ID provided.'], 400);
        }

        $stmt = $conn->prepare("
            SELECT wl.*, COALESCE(SUM(i.quantity), 0) AS occupied_capacity
            FROM warehouse_locations wl
            LEFT JOIN inventory i ON wl.location_id = i.location_id AND wl.warehouse_id = i.warehouse_id
            WHERE wl.location_id = ? AND wl.warehouse_id = ?
            GROUP BY wl.location_id
        ");
        $stmt->bind_param("ii", $location_id, $warehouse_id);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($location = $result->fetch_assoc()) {
            $max_cap = $location['max_capacity_units'];
            $occupied = $location['occupied_capacity'];
            $location['available_capacity'] = ($max_cap !== null) ? ($max_cap - $occupied) : null;
            $location['is_full'] = ($max_cap !== null && $location['available_capacity'] <= 0);
            sendJsonResponse(['success' => true, 'data' => $location]);
        } else {
            sendJsonResponse(['success' => false, 'message' => 'Location not found or not in selected warehouse'], 404);
        }
        $stmt->close();
    } else {
        $stmt = $conn->prepare("
            SELECT 
                wl.location_id, wl.location_code, wl.location_type, 
                wl.max_capacity_units, wl.max_capacity_weight, wl.max_capacity_volume, 
                wl.is_active, COALESCE(SUM(i.quantity), 0) AS occupied_capacity
            FROM warehouse_locations wl
            LEFT JOIN inventory i ON wl.location_id = i.location_id AND wl.warehouse_id = i.warehouse_id
            WHERE wl.warehouse_id = ? 
            GROUP BY wl.location_id
            ORDER BY wl.location_code ASC
        ");
        $stmt->bind_param("i", $warehouse_id);
        $stmt->execute();
        $result = $stmt->get_result();
        $locations = [];

        while ($row = $result->fetch_assoc()) {
            $max_cap = $row['max_capacity_units'];
            $occupied = $row['occupied_capacity'];
            $row['available_capacity'] = ($max_cap !== null) ? ($max_cap - $occupied) : null;
            $row['is_full'] = ($max_cap !== null && $row['available_capacity'] <= 0);
            $locations[] = $row;
        }
        $stmt->close();
        sendJsonResponse(['success' => true, 'data' => $locations]);
    }
}

function handleCreateLocation($conn, $warehouse_id) {
    $input = json_decode(file_get_contents('php://input'), true);

    $location_code = sanitize_input($input['location_code'] ?? '');
    if (empty($location_code)) {
        sendJsonResponse(['success' => false, 'message' => 'Location Code is required'], 400);
    }
    
    // Sanitize and validate other inputs
    $location_type = sanitize_input($input['location_type'] ?? 'shelf');
    $max_capacity_units = isset($input['max_capacity_units']) && $input['max_capacity_units'] !== '' ? filter_var($input['max_capacity_units'], FILTER_VALIDATE_INT) : null;
    $max_capacity_weight = isset($input['max_capacity_weight']) && $input['max_capacity_weight'] !== '' ? filter_var($input['max_capacity_weight'], FILTER_VALIDATE_FLOAT, FILTER_FLAG_ALLOW_FRACTION) : null;
    $max_capacity_volume = isset($input['max_capacity_volume']) && $input['max_capacity_volume'] !== '' ? filter_var($input['max_capacity_volume'], FILTER_VALIDATE_FLOAT, FILTER_FLAG_ALLOW_FRACTION) : null;
    $is_active = isset($input['is_active']) ? (bool)$input['is_active'] : true;


    // Check uniqueness of location code within the warehouse
    $stmt = $conn->prepare("SELECT location_id FROM warehouse_locations WHERE location_code = ? AND warehouse_id = ?");
    $stmt->bind_param("si", $location_code, $warehouse_id);
    $stmt->execute();
    if ($stmt->get_result()->num_rows > 0) {
        sendJsonResponse(['success' => false, 'message' => 'Location Code already exists in this warehouse.'], 409);
        $stmt->close();
        return;
    }
    $stmt->close();

    $stmt = $conn->prepare("INSERT INTO warehouse_locations (warehouse_id, location_code, location_type, max_capacity_units, max_capacity_weight, max_capacity_volume, is_active) VALUES (?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("issiddi", $warehouse_id, $location_code, $location_type, $max_capacity_units, $max_capacity_weight, $max_capacity_volume, $is_active);

    if ($stmt->execute()) {
        sendJsonResponse(['success' => true, 'message' => 'Location created successfully', 'location_id' => $stmt->insert_id], 201);
    } else {
        sendJsonResponse(['success' => false, 'message' => 'Failed to create location', 'error' => $stmt->error], 500);
    }
    $stmt->close();
}

function handleUpdateLocation($conn, $warehouse_id) {
    $input = json_decode(file_get_contents('php://input'), true);

    $location_id = filter_var($input['location_id'] ?? null, FILTER_VALIDATE_INT);
    if (!$location_id) {
        sendJsonResponse(['success' => false, 'message' => 'Location ID is required and must be an integer.'], 400);
    }

    $fields = ['location_code', 'location_type', 'max_capacity_units', 'max_capacity_weight', 'max_capacity_volume', 'is_active'];
    $set_clauses = [];
    $bind_params = [];
    $bind_types = "";

    foreach ($fields as $field) {
        if (array_key_exists($field, $input)) {
            $set_clauses[] = "$field = ?";
            $value = $input[$field];
            
            if ($field === 'location_code' || $field === 'location_type') {
                $bind_params[] = sanitize_input($value);
                $bind_types .= "s";
            } elseif ($field === 'is_active') {
                $bind_params[] = (int)(bool)$value;
                $bind_types .= "i";
            } elseif ($field === 'max_capacity_units') {
                $bind_params[] = ($value === '' || $value === null) ? null : filter_var($value, FILTER_VALIDATE_INT);
                $bind_types .= "i";
            } else { // weight, volume
                $bind_params[] = ($value === '' || $value === null) ? null : filter_var($value, FILTER_VALIDATE_FLOAT, FILTER_FLAG_ALLOW_FRACTION);
                $bind_types .= "d";
            }
        }
    }

    if (empty($set_clauses)) {
        sendJsonResponse(['success' => true, 'message' => 'No fields provided for update.'], 200);
        return;
    }

    $sql = "UPDATE warehouse_locations SET " . implode(", ", $set_clauses) . " WHERE location_id = ? AND warehouse_id = ?";
    $bind_types .= "ii";
    $bind_params[] = $location_id;
    $bind_params[] = $warehouse_id;

    $stmt = $conn->prepare($sql);
    $stmt->bind_param($bind_types, ...$bind_params);

    if ($stmt->execute()) {
        if ($stmt->affected_rows > 0) {
            sendJsonResponse(['success' => true, 'message' => 'Location updated successfully.'], 200);
        } else {
            sendJsonResponse(['success' => true, 'message' => 'No changes were made to the location.'], 200);
        }
    } else {
        if ($conn->errno == 1062) {
             sendJsonResponse(['success' => false, 'message' => 'Update failed: This Location Code is already in use.'], 409);
        } else {
             sendJsonResponse(['success' => false, 'message' => 'Failed to update location.', 'error' => $stmt->error], 500);
        }
    }
    $stmt->close();
}

function handleDeleteLocation($conn, $warehouse_id) {
    $location_id = filter_var($_GET['id'] ?? null, FILTER_VALIDATE_INT);
    if (!$location_id) {
        sendJsonResponse(['success' => false, 'message' => 'Location ID is required for deletion'], 400);
    }
    
    // Check for inventory before deleting.
    $stmt_check = $conn->prepare("SELECT COUNT(*) as inventory_count FROM inventory WHERE location_id = ? AND warehouse_id = ?");
    $stmt_check->bind_param("ii", $location_id, $warehouse_id);
    $stmt_check->execute();
    $inventory_count = $stmt_check->get_result()->fetch_assoc()['inventory_count'];
    $stmt_check->close();

    if ($inventory_count > 0) {
        sendJsonResponse(['success' => false, 'message' => 'Cannot delete location: It still contains inventory.'], 400);
        return;
    }

    // Proceed with deletion.
    $stmt = $conn->prepare("DELETE FROM warehouse_locations WHERE location_id = ? AND warehouse_id = ?");
    $stmt->bind_param("ii", $location_id, $warehouse_id);

    if ($stmt->execute()) {
        if ($stmt->affected_rows > 0) {
            sendJsonResponse(['success' => true, 'message' => 'Location deleted successfully'], 200);
        } else {
            sendJsonResponse(['success' => false, 'message' => 'Location not found in the selected warehouse'], 404);
        }
    } else {
        sendJsonResponse(['success' => false, 'message' => 'Failed to delete location', 'error' => $stmt->error], 500);
    }
    $stmt->close();
}
