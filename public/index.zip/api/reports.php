<?php
// api/reports.php

// CRITICAL: Ensure NO whitespace, BOM, or any characters before this opening PHP tag.

require_once __DIR__ . '/../config/config.php';

// FIX: Initialize $conn immediately after including config.php
$conn = getDbConnection();

// CRITICAL: Start Output Buffering at the very beginning of the script.
ob_start();

// Authenticate user AND ensure warehouse is selected for reports
authenticate_user(); // This will default to true, requiring warehouse_id
$current_warehouse_id = get_current_warehouse_id();
if (!$current_warehouse_id) {
    // This condition should ideally be caught by authenticate_user()
    // but acts as a fallback.
    sendJsonResponse(['message' => 'No warehouse selected for reporting.', 'error' => true], 400);
}


$action = $_GET['action'] ?? '';

switch ($action) {
    case 'dashboardSummary':
        getDashboardSummary($conn, $current_warehouse_id);
        break;
    case 'inventorySummary':
        getInventorySummary($conn, $current_warehouse_id);
        break;
    case 'inboundHistory':
        getInboundHistory($conn, $current_warehouse_id);
        break;
    case 'outboundHistory':
        getOutboundHistory($conn, $current_warehouse_id);
        break;
    case 'stockByLocation':
        getStockByLocation($conn, $current_warehouse_id);
        break;
    case 'productMovement':
        getProductMovement($conn, $current_warehouse_id);
        break;
    default:
        sendJsonResponse(['message' => 'Invalid report action'], 400);
        break;
}

// No $conn->close() needed here because sendJsonResponse() includes an exit().

function getDashboardSummary($conn, $warehouse_id) {
    $summary = [
        'totalProducts' => 0,
        'openInbounds' => 0,
        'pendingOutbounds' => 0
    ];

    // Total Products in Warehouse (sum of quantities from inventory)
    $stmt = $conn->prepare("SELECT SUM(quantity) AS total_qty FROM inventory WHERE warehouse_id = ?");
    $stmt->bind_param("i", $warehouse_id);
    $stmt->execute();
    $result = $stmt->get_result()->fetch_assoc();
    $summary['totalProducts'] = $result['total_qty'] ?? 0;
    $stmt->close();

    // Open Inbound Receipts (Pending, Partially Received)
    $stmt = $conn->prepare("SELECT COUNT(*) AS count FROM inbound_receipts WHERE warehouse_id = ? AND (status = 'Pending' OR status = 'Partially Received')");
    $stmt->bind_param("i", $warehouse_id);
    $stmt->execute();
    $result = $stmt->get_result()->fetch_assoc();
    $summary['openInbounds'] = $result['count'] ?? 0;
    $stmt->close();

    // Pending Outbound Orders (New, Pending Pick, Partially Picked)
    $stmt = $conn->prepare("SELECT COUNT(*) AS count FROM outbound_orders WHERE warehouse_id = ? AND (status = 'New' OR status = 'Pending Pick' OR status = 'Partially Picked')");
    $stmt->bind_param("i", $warehouse_id);
    $stmt->execute();
    $result = $stmt->get_result()->fetch_assoc();
    $summary['pendingOutbounds'] = $result['count'] ?? 0;
    $stmt->close();

    sendJsonResponse($summary);
}


function getInventorySummary($conn, $warehouse_id) {
    $sql = "
        SELECT
            p.sku,
            p.product_name,
            SUM(i.quantity) AS total_quantity,
            COUNT(DISTINCT i.location_id) AS distinct_locations,
            GROUP_CONCAT(wl.location_code ORDER BY wl.location_code SEPARATOR ', ') AS locations_list
        FROM
            inventory i
        JOIN
            products p ON i.product_id = p.product_id
        JOIN
            warehouse_locations wl ON i.location_id = wl.location_id
        WHERE
            i.warehouse_id = ?
        GROUP BY
            p.product_id, p.sku, p.product_name
        ORDER BY
            p.product_name ASC
    ";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $warehouse_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $report_data = [];
    while ($row = $result->fetch_assoc()) {
        $report_data[] = $row;
    }
    $stmt->close();
    sendJsonResponse($report_data);
}

function getInboundHistory($conn, $warehouse_id) {
    $start_date = sanitize_input($_GET['start_date'] ?? null);
    $end_date = sanitize_input($_GET['end_date'] ?? null);

    $sql = "
        SELECT
            ir.receipt_number,
            ir.supplier_name,
            ir.actual_arrival_date,
            ir.status AS receipt_status,
            p.sku,
            p.product_name,
            ii.expected_quantity,
            ii.received_quantity,
            ii.putaway_quantity,
            wl.location_code AS final_location,
            u.full_name AS received_by_user
        FROM
            inbound_receipts ir
        JOIN
            inbound_items ii ON ir.receipt_id = ii.receipt_id
        JOIN
            products p ON ii.product_id = p.product_id
        LEFT JOIN
            warehouse_locations wl ON ii.final_location_id = wl.location_id
        LEFT JOIN
            users u ON ir.received_by = u.user_id
        WHERE ir.warehouse_id = ?
    ";

    $params = [&$warehouse_id];
    $types = "i";

    if ($start_date) {
        $sql .= " AND ir.actual_arrival_date >= ?";
        $params[] = &$start_date;
        $types .= "s";
    }
    if ($end_date) {
        $sql .= " AND ir.actual_arrival_date <= ?";
        $params[] = &$end_date;
        $types .= "s";
    }

    $sql .= " ORDER BY ir.actual_arrival_date DESC, ir.receipt_number ASC";

    $stmt = $conn->prepare($sql);
    call_user_func_array([$stmt, 'bind_param'], array_merge([$types], $params));
    $stmt->execute();
    $result = $stmt->get_result();
    $report_data = [];
    while ($row = $result->fetch_assoc()) {
        $report_data[] = $row;
    }
    $stmt->close();
    sendJsonResponse($report_data);
}

function getOutboundHistory($conn, $warehouse_id) {
    $start_date = sanitize_input($_GET['start_date'] ?? null);
    $end_date = sanitize_input($_GET['end_date'] ?? null);

    $sql = "
        SELECT
            oo.order_number,
            c.customer_name,
            oo.order_date,
            oo.actual_ship_date,
            oo.status AS order_status,
            p.sku,
            p.product_name,
            oi.ordered_quantity,
            oi.picked_quantity,
            oi.shipped_quantity,
            wl.location_code AS picked_from_location,
            picker.full_name AS picked_by_user,
            shipper.full_name AS shipped_by_user
        FROM
            outbound_orders oo
        JOIN
            outbound_items oi ON oo.order_id = oi.order_id
        JOIN
            products p ON oi.product_id = p.product_id
        JOIN
            customers c ON oo.customer_id = c.customer_id
        LEFT JOIN
            warehouse_locations wl ON oi.picked_from_location_id = wl.location_id
        LEFT JOIN
            users picker ON oo.picked_by = picker.user_id
        LEFT JOIN
            users shipper ON oo.shipped_by = shipper.user_id
        WHERE oo.warehouse_id = ?
    ";

    $params = [&$warehouse_id];
    $types = "i";

    if ($start_date) {
        $sql .= " AND oo.order_date >= ?";
        $params[] = &$start_date;
        $types .= "s";
    }
    if ($end_date) {
        $sql .= " AND oo.order_date <= ?";
        $params[] = &$end_date;
        $types .= "s";
    }

    $sql .= " ORDER BY oo.order_date DESC, oo.order_number ASC";

    $stmt = $conn->prepare($sql);
    call_user_func_array([$stmt, 'bind_param'], array_merge([$types], $params));
    $stmt->execute();
    $result = $stmt->get_result();
    $report_data = [];
    while ($row = $result->fetch_assoc()) {
        $report_data[] = $row;
    }
    $stmt->close();
    sendJsonResponse($report_data);
}

function getStockByLocation($conn, $warehouse_id) {
    $sql = "
        SELECT
            wl.location_code,
            wl.location_type,
            p.sku,
            p.product_name,
            i.quantity,
            i.batch_number,
            i.expiry_date
        FROM
            inventory i
        JOIN
            warehouse_locations wl ON i.location_id = wl.location_id
        JOIN
            products p ON i.product_id = p.product_id
        WHERE
            i.warehouse_id = ?
        ORDER BY
            wl.location_code ASC, p.product_name ASC
    ";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $warehouse_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $report_data = [];
    while ($row = $result->fetch_assoc()) {
        $report_data[] = $row;
    }
    $stmt->close();
    sendJsonResponse($report_data);
}

function getProductMovement($conn, $warehouse_id) {
    $product_id = sanitize_input($_GET['product_id'] ?? null);
    $sku = sanitize_input($_GET['sku'] ?? null);

    // Inbound movements
    $sql_inbound = "
        SELECT
            'INBOUND' AS movement_type,
            ir.receipt_number AS transaction_ref,
            ir.actual_arrival_date AS transaction_date,
            p.product_name,
            ii.received_quantity AS quantity_change,
            wl_final.location_code AS to_location,
            NULL AS from_location,
            ir.status AS status,
            u.full_name AS performed_by
        FROM
            inbound_items ii
        JOIN
            inbound_receipts ir ON ii.receipt_id = ir.receipt_id
        JOIN
            products p ON ii.product_id = p.product_id
        LEFT JOIN
            warehouse_locations wl_final ON ii.final_location_id = wl_final.location_id
        LEFT JOIN
            users u ON ir.received_by = u.user_id
        WHERE ir.warehouse_id = ?
    ";
    $inbound_params = [&$warehouse_id];
    $inbound_types = "i";

    if ($product_id) {
        $sql_inbound .= " AND ii.product_id = ?";
        $inbound_params[] = &$product_id;
        $inbound_types .= "i";
    } elseif ($sku) {
        $sql_inbound .= " AND p.sku = ?";
        $inbound_params[] = &$sku;
        $inbound_types .= "s";
    }

    // Outbound movements
    $sql_outbound = "
        SELECT
            'OUTBOUND' AS movement_type,
            oo.order_number AS transaction_ref,
            oo.actual_ship_date AS transaction_date,
            p.product_name,
            -oi.shipped_quantity AS quantity_change, -- Negative for outbound
            NULL AS to_location,
            wl_picked.location_code AS from_location,
            oo.status AS status,
            u_shipper.full_name AS performed_by
        FROM
            outbound_items oi
        JOIN
            outbound_orders oo ON oi.order_id = oo.order_id
        JOIN
            products p ON oi.product_id = p.product_id
        LEFT JOIN
            warehouse_locations wl_picked ON oi.picked_from_location_id = wl_picked.location_id
        LEFT JOIN
            users u_shipper ON oo.shipped_by = u_shipper.user_id
        WHERE oo.warehouse_id = ?
    ";
    $outbound_params = [&$warehouse_id];
    $outbound_types = "i";

    if ($product_id) {
        $sql_outbound .= " AND oi.product_id = ?";
        $outbound_params[] = &$product_id;
        $outbound_types .= "i";
    } elseif ($sku) {
        $sql_outbound .= " AND p.sku = ?";
        $outbound_params[] = &$sku;
        $outbound_types .= "s";
    }

    // Combine queries
    $final_sql = "(" . $sql_inbound . ") UNION ALL (" . $sql_outbound . ") ORDER BY transaction_date DESC, movement_type ASC";

    $stmt = $conn->prepare($final_sql);
    
    // Combine parameters and types for UNION ALL
    $all_params = array_merge($inbound_params, $outbound_params);
    $all_types = $inbound_types . $outbound_types;

    call_user_func_array([$stmt, 'bind_param'], array_merge([$all_types], $all_params));

    $stmt->execute();
    $result = $stmt->get_result();
    $report_data = [];
    while ($row = $result->fetch_assoc()) {
        $report_data[] = $row;
    }
    $stmt->close();
    sendJsonResponse($report_data);
}
