<?php
// api/inventory.php

require_once __DIR__ . '/../config/config.php';

$conn = getDbConnection();
ob_start();

// Authenticate user and ensure a warehouse is selected for ALL inventory operations.
authenticate_user(true, null);
$current_warehouse_id = get_current_warehouse_id();

$method = $_SERVER['REQUEST_METHOD'];

// Authorize based on the request method and user's role.
switch ($method) {
    case 'GET':
        authorize_user_role(['viewer', 'operator', 'manager']);
        handleGetInventory($conn, $current_warehouse_id);
        break;
    case 'POST':
        authorize_user_role(['operator', 'manager']);
        handleInventoryAdjustment($conn, $current_warehouse_id);
        break;
    default:
        sendJsonResponse(['success' => false, 'message' => 'Method Not Allowed'], 405);
        break;
}

function handleGetInventory($conn, $warehouse_id) {
    // Sanitize all GET parameters
    $product_id = filter_input(INPUT_GET, 'product_id', FILTER_VALIDATE_INT);
    $location_id = filter_input(INPUT_GET, 'location_id', FILTER_VALIDATE_INT);
    $sku = sanitize_input($_GET['sku'] ?? '');
    $barcode = sanitize_input($_GET['barcode'] ?? '');
    $location_code = sanitize_input($_GET['location_code'] ?? '');
    $product_barcode_search = sanitize_input($_GET['product_barcode'] ?? '');

    if (!empty($product_barcode_search)) {
        handleBarcodeSearch($conn, $warehouse_id, $product_barcode_search);
        return;
    }

    $is_product_summary = ($product_id || !empty($sku) || !empty($barcode)) && !$location_id && empty($location_code);

    if ($is_product_summary) {
        // --- UPDATED SUMMARY QUERY ---
        // This query now includes product details so the frontend doesn't have to guess.
        $sql = "
            SELECT
                p.sku,
                p.product_name,
                p.barcode,
                wl.location_code,
                SUM(i.quantity) AS total_quantity_at_location
            FROM inventory i
            JOIN products p ON i.product_id = p.product_id
            JOIN warehouse_locations wl ON i.location_id = wl.location_id
            WHERE i.warehouse_id = ? AND i.quantity > 0
        ";
        $params = [$warehouse_id];
        $types = "i";

        if ($product_id) { $sql .= " AND i.product_id = ?"; $params[] = $product_id; $types .= "i"; }
        if (!empty($sku)) { $sql .= " AND p.sku = ?"; $params[] = $sku; $types .= "s"; }
        if (!empty($barcode)) { $sql .= " AND p.barcode = ?"; $params[] = $barcode; $types .= "s"; }

        $sql .= " GROUP BY p.product_id, p.sku, p.product_name, p.barcode, wl.location_id, wl.location_code ORDER BY wl.location_code ASC";

    } else {
        // Detailed inventory list (no changes here)
        $sql = "
            SELECT
                i.inventory_id, i.quantity, i.batch_number, i.expiry_date, i.last_moved_at,
                p.sku, p.product_name, p.barcode,
                wl.location_code, wl.location_type
            FROM inventory i
            JOIN products p ON i.product_id = p.product_id
            JOIN warehouse_locations wl ON i.location_id = wl.location_id
            WHERE i.warehouse_id = ?
        ";
        $params = [$warehouse_id];
        $types = "i";

        if ($product_id) { $sql .= " AND i.product_id = ?"; $params[] = $product_id; $types .= "i"; }
        if ($location_id) { $sql .= " AND i.location_id = ?"; $params[] = $location_id; $types .= "i"; }
        if (!empty($sku)) { $sql .= " AND p.sku LIKE ?"; $params[] = "%$sku%"; $types .= "s"; }
        if (!empty($barcode)) { $sql .= " AND p.barcode = ?"; $params[] = $barcode; $types .= "s"; }
        if (!empty($location_code)) { $sql .= " AND wl.location_code LIKE ?"; $params[] = "%$location_code%"; $types .= "s"; }
        
        $sql .= " ORDER BY p.product_name, wl.location_code";
    }

    $stmt = $conn->prepare($sql);
    $stmt->bind_param($types, ...$params);
    $stmt->execute();
    $inventory_data = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    $stmt->close();
    
    sendJsonResponse(['success' => true, 'data' => $inventory_data]);
}

function handleInventoryAdjustment($conn, $warehouse_id) {
    $input = json_decode(file_get_contents('php://input'), true);
    $action_type = sanitize_input($input['action_type'] ?? '');

    if (empty($action_type)) {
        sendJsonResponse(['success' => false, 'message' => "Action type is required."], 400);
        return;
    }

    $conn->begin_transaction();
    try {
        if ($action_type === 'adjust_quantity') {
            adjustInventoryQuantity($conn, $input, $warehouse_id);
        } elseif ($action_type === 'transfer') {
            transferInventory($conn, $input, $warehouse_id);
        } else {
            throw new Exception('Invalid action type provided.');
        }
    } catch (Exception $e) {
        $conn->rollback();
        error_log("Inventory adjustment error: " . $e->getMessage());
        sendJsonResponse(['success' => false, 'message' => $e->getMessage()], 400);
    }
}

function adjustInventoryQuantity($conn, $input, $warehouse_id) {
    // Validation and Sanitization
    $product_barcode = sanitize_input($input['product_barcode'] ?? '');
    $location_barcode = sanitize_input($input['current_location_barcode'] ?? '');
    $quantity_change = filter_var($input['quantity_change'] ?? 0, FILTER_VALIDATE_INT);
    $batch_number = sanitize_input($input['batch_number'] ?? null) ?: null;
    $expiry_date = sanitize_input($input['expiry_date'] ?? null) ?: null;

    if (empty($product_barcode) || empty($location_barcode) || $quantity_change === false || $quantity_change === 0) {
        throw new Exception("Product barcode, location barcode, and a non-zero quantity are required.");
    }
    
    $product_id = getProductIdFromBarcode($conn, $product_barcode);
    $location_data = getLocationDataFromBarcode($conn, $location_barcode, $warehouse_id);
    $location_id = $location_data['location_id'];

    if ($quantity_change > 0 && $location_data['max_capacity_units'] !== null) {
        $stmt_total = $conn->prepare("SELECT COALESCE(SUM(quantity), 0) AS total FROM inventory WHERE location_id = ? AND warehouse_id = ?");
        $stmt_total->bind_param("ii", $location_id, $warehouse_id);
        $stmt_total->execute();
        $current_total_qty = $stmt_total->get_result()->fetch_assoc()['total'];
        $stmt_total->close();
        if (($current_total_qty + $quantity_change) > $location_data['max_capacity_units']) {
            throw new Exception("Location has insufficient capacity.");
        }
    }

    if ($quantity_change < 0) {
        $stmt_check = $conn->prepare("SELECT quantity FROM inventory WHERE product_id = ? AND location_id = ? AND warehouse_id = ? AND batch_number <=> ?");
        $stmt_check->bind_param("iiis", $product_id, $location_id, $warehouse_id, $batch_number);
        $stmt_check->execute();
        $existing_inv = $stmt_check->get_result()->fetch_assoc();
        $stmt_check->close();
        if (!$existing_inv || $existing_inv['quantity'] < abs($quantity_change)) {
             throw new Exception("Insufficient stock for this batch to perform decrement.");
        }
    }

    $stmt_upsert = $conn->prepare("INSERT INTO inventory (warehouse_id, product_id, location_id, quantity, batch_number, expiry_date) VALUES (?, ?, ?, ?, ?, ?) ON DUPLICATE KEY UPDATE quantity = quantity + VALUES(quantity), last_moved_at = CURRENT_TIMESTAMP");
    $stmt_upsert->bind_param("iiiiss", $warehouse_id, $product_id, $location_id, $quantity_change, $batch_number, $expiry_date);
    if (!$stmt_upsert->execute()) {
        throw new Exception("Failed to adjust inventory. If updating, ensure batch number and expiry date match existing stock.");
    }
    $stmt_upsert->close();
    
    $stmt_cleanup = $conn->prepare("DELETE FROM inventory WHERE warehouse_id = ? AND quantity <= 0");
    $stmt_cleanup->bind_param("i", $warehouse_id);
    $stmt_cleanup->execute();
    $stmt_cleanup->close();

    $conn->commit();
    sendJsonResponse(['success' => true, 'message' => 'Inventory quantity adjusted successfully.']);
}

function transferInventory($conn, $input, $warehouse_id) {
    $product_barcode = sanitize_input($input['product_barcode'] ?? '');
    $from_location_barcode = sanitize_input($input['current_location_barcode'] ?? '');
    $to_location_barcode = sanitize_input($input['new_location_barcode'] ?? '');
    $quantity = filter_var($input['quantity_change'] ?? 0, FILTER_VALIDATE_INT);
    $batch_number = sanitize_input($input['batch_number'] ?? null);

    if (empty($product_barcode) || empty($from_location_barcode) || empty($to_location_barcode) || $quantity <= 0) {
        throw new Exception("Product, from/to locations, and a positive quantity are required for transfer.");
    }
    if ($from_location_barcode === $to_location_barcode) {
        throw new Exception("Cannot transfer to the same location.");
    }

    $product_id = getProductIdFromBarcode($conn, $product_barcode);
    $from_location_id = getLocationDataFromBarcode($conn, $from_location_barcode, $warehouse_id)['location_id'];
    $to_location_id = getLocationDataFromBarcode($conn, $to_location_barcode, $warehouse_id)['location_id'];

    $stmt_find = $conn->prepare("SELECT inventory_id, quantity, expiry_date FROM inventory WHERE product_id = ? AND location_id = ? AND warehouse_id = ? AND batch_number <=> ? LIMIT 1");
    $stmt_find->bind_param("iiis", $product_id, $from_location_id, $warehouse_id, $batch_number);
    $stmt_find->execute();
    $source_item = $stmt_find->get_result()->fetch_assoc();
    $stmt_find->close();

    if (!$source_item || $source_item['quantity'] < $quantity) {
        throw new Exception("Insufficient quantity of the specified item/batch at the source location.");
    }

    $stmt_dec = $conn->prepare("UPDATE inventory SET quantity = quantity - ? WHERE inventory_id = ?");
    $stmt_dec->bind_param("ii", $quantity, $source_item['inventory_id']);
    $stmt_dec->execute();
    $stmt_dec->close();

    $stmt_inc = $conn->prepare("INSERT INTO inventory (warehouse_id, product_id, location_id, quantity, batch_number, expiry_date) VALUES (?, ?, ?, ?, ?, ?) ON DUPLICATE KEY UPDATE quantity = quantity + VALUES(quantity), last_moved_at = CURRENT_TIMESTAMP");
    $stmt_inc->bind_param("iiiiss", $warehouse_id, $product_id, $to_location_id, $quantity, $batch_number, $source_item['expiry_date']);
    $stmt_inc->execute();
    $stmt_inc->close();

    $stmt_clean = $conn->prepare("DELETE FROM inventory WHERE inventory_id = ? AND quantity <= 0");
    $stmt_clean->bind_param("i", $source_item['inventory_id']);
    $stmt_clean->execute();
    $stmt_clean->close();

    $conn->commit();
    sendJsonResponse(['success' => true, 'message' => 'Inventory transferred successfully.']);
}

function handleBarcodeSearch($conn, $warehouse_id, $barcode) {
    if (empty($barcode)) {
        sendJsonResponse(['success' => false, 'message' => 'Product barcode is required'], 400);
        return;
    }
    
    $product_id = getProductIdFromBarcode($conn, $barcode);

    $stmt = $conn->prepare("
        SELECT i.quantity, i.batch_number, i.expiry_date, wl.location_id, wl.location_code
        FROM inventory i
        JOIN warehouse_locations wl ON i.location_id = wl.location_id
        WHERE i.product_id = ? AND i.warehouse_id = ? AND i.quantity > 0
        ORDER BY wl.location_code ASC, i.expiry_date ASC
    ");
    $stmt->bind_param("ii", $product_id, $warehouse_id);
    $stmt->execute();
    $inventory_details = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    $stmt->close();

    sendJsonResponse(['success' => true, 'data' => $inventory_details]);
}

function getProductIdFromBarcode($conn, $barcode) {
    $stmt = $conn->prepare("SELECT product_id FROM products WHERE barcode = ?");
    $stmt->bind_param("s", $barcode);
    $stmt->execute();
    $result = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    if (!$result) throw new Exception("Product not found with barcode: {$barcode}");
    return $result['product_id'];
}

function getLocationDataFromBarcode($conn, $location_code, $warehouse_id) {
    $stmt = $conn->prepare("SELECT location_id, max_capacity_units FROM warehouse_locations WHERE location_code = ? AND warehouse_id = ?");
    $stmt->bind_param("si", $location_code, $warehouse_id);
    $stmt->execute();
    $result = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    if (!$result) throw new Exception("Location '{$location_code}' not found in this warehouse.");
    return $result;
}
