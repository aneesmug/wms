// public/js/products.js

document.addEventListener('DOMContentLoaded', () => {
    // --- DOM Elements ---
    const productForm = document.getElementById('productForm');
    const productFormTitle = document.getElementById('productFormTitle');
    const productIdInput = document.getElementById('productId');
    const productsTableBody = document.getElementById('productsTableBody');
    const saveProductBtn = document.getElementById('saveProductBtn');
    const cancelEditBtn = document.getElementById('cancelEditBtn');
    const logoutBtn = document.getElementById('logoutBtn');

    // Form fields
    const skuInput = document.getElementById('sku');
    const productNameInput = document.getElementById('productName');
    const descriptionInput = document.getElementById('description');
    const unitOfMeasureInput = document.getElementById('unitOfMeasure');
    const weightInput = document.getElementById('weight');
    const volumeInput = document.getElementById('volume');
    const barcodeInput = document.getElementById('barcode');

    // Get user's role for the current warehouse from localStorage
    const currentWarehouseRole = localStorage.getItem('current_warehouse_role');

    // --- Initialize Page ---
    initializePage();

    // --- Event Listeners ---
    if (productForm) {
        productForm.addEventListener('submit', handleSaveProduct);
    }
    if (cancelEditBtn) {
        cancelEditBtn.addEventListener('click', resetProductForm);
    }
    if (logoutBtn) {
        logoutBtn.addEventListener('click', handleLogout);
    }

    /**
     * Initializes the page, setting UI visibility based on role and loading data.
     */
    async function initializePage() {
        // Determine if the user has management permissions for products.
        const canManageProducts = currentWarehouseRole === 'operator' || currentWarehouseRole === 'manager';
        
        if (productForm) {
            if (canManageProducts) {
                productForm.style.display = 'grid'; // Show form
            } else {
                productForm.style.display = 'none'; // Hide form for viewers
                showMessageBox("You have view-only permissions for products.", "info", 4000);
            }
        }
        await loadProducts();
    }

    /**
     * Fetches and displays the list of products. Action buttons are shown based on role.
     */
    async function loadProducts() {
        if (!productsTableBody) return;
        productsTableBody.innerHTML = `<tr><td colspan="7" class="px-6 py-4 text-center">Loading products...</td></tr>`;

        const response = await fetchData('api/products.php');
        productsTableBody.innerHTML = '';

        if (response?.success && Array.isArray(response.data)) {
            if (response.data.length === 0) {
                productsTableBody.innerHTML = `<tr><td colspan="7" class="px-6 py-4 text-center">No products found.</td></tr>`;
                return;
            }

            const canEdit = currentWarehouseRole === 'operator' || currentWarehouseRole === 'manager';
            const canDelete = currentWarehouseRole === 'manager';

            response.data.forEach(product => {
                const row = productsTableBody.insertRow();
                
                let actionsHtml = '';
                if (canEdit) {
                    actionsHtml += `<button data-id="${product.product_id}" class="edit-btn text-indigo-600 hover:text-indigo-900 mr-3">Edit</button>`;
                }
                if (canDelete) {
                    actionsHtml += `<button data-id="${product.product_id}" class="delete-btn text-red-600 hover:text-red-900">Delete</button>`;
                }
                if (!actionsHtml) {
                    actionsHtml = `<span class="text-gray-400">View Only</span>`;
                }

                row.innerHTML = `
                    <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">${product.sku}</td>
                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">${product.product_name}</td>
                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">${product.barcode || 'N/A'}</td>
                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">${product.unit_of_measure || 'N/A'}</td>
                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">${product.weight || 'N/A'}</td>
                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">${product.volume || 'N/A'}</td>
                    <td class="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">${actionsHtml}</td>
                `;
            });
            addTableButtonListeners();
        } else {
            productsTableBody.innerHTML = `<tr><td colspan="7" class="px-6 py-4 text-center">Error loading products.</td></tr>`;
            showMessageBox(response?.message || 'Failed to load product data.', 'error');
        }
    }

    async function handleSaveProduct(event) {
        event.preventDefault();
        
        const data = {
            product_id: productIdInput.value,
            sku: skuInput.value.trim(),
            product_name: productNameInput.value.trim(),
            description: descriptionInput.value.trim(),
            unit_of_measure: unitOfMeasureInput.value.trim(),
            weight: weightInput.value.trim(),
            volume: volumeInput.value.trim(),
            barcode: barcodeInput.value.trim()
        };

        if (!data.sku || !data.product_name) {
            showMessageBox('SKU and Product Name are required.', 'error');
            return;
        }

        const isUpdating = !!data.product_id;
        const method = isUpdating ? 'PUT' : 'POST';
        
        saveProductBtn.disabled = true;
        saveProductBtn.textContent = 'Saving...';

        const result = await fetchData('api/products.php', method, data);
        
        if (result?.success) {
            showMessageBox(result.message, 'success');
            resetProductForm();
            await loadProducts();
        }

        saveProductBtn.disabled = false;
        saveProductBtn.textContent = isUpdating ? 'Update Product' : 'Save Product';
    }

    async function handleEditProduct(event) {
        const id = event.target.dataset.id;
        const response = await fetchData(`api/products.php?id=${id}`);
        if (response?.success) {
            const product = response.data;
            productIdInput.value = product.product_id;
            skuInput.value = product.sku;
            productNameInput.value = product.product_name;
            descriptionInput.value = product.description;
            unitOfMeasureInput.value = product.unit_of_measure;
            weightInput.value = product.weight;
            volumeInput.value = product.volume;
            barcodeInput.value = product.barcode;

            productFormTitle.textContent = 'Edit Product';
            saveProductBtn.textContent = 'Update Product';
            cancelEditBtn.style.display = 'inline-flex';
            window.scrollTo({ top: 0, behavior: 'smooth' });
        } else {
             showMessageBox(response?.message || 'Failed to load product for editing.', 'error');
        }
    }

    async function handleDeleteProduct(event) {
        const id = event.target.dataset.id;
        if (confirm('Are you sure you want to delete this product? This action cannot be undone.')) {
            const result = await fetchData(`api/products.php?id=${id}`, 'DELETE');
            if (result?.success) {
                showMessageBox('Product deleted successfully!', 'success');
                await loadProducts();
                resetProductForm();
            }
        }
    }

    function resetProductForm() {
        productForm.reset();
        productIdInput.value = '';
        productFormTitle.textContent = 'Add New Product';
        saveProductBtn.textContent = 'Save Product';
        cancelEditBtn.style.display = 'none';
    }

    function addTableButtonListeners() {
        const canEdit = currentWarehouseRole === 'operator' || currentWarehouseRole === 'manager';
        const canDelete = currentWarehouseRole === 'manager';
        
        if(canEdit){
            document.querySelectorAll('.edit-btn').forEach(button => {
                button.addEventListener('click', handleEditProduct);
            });
        }
        if(canDelete){
             document.querySelectorAll('.delete-btn').forEach(button => {
                button.addEventListener('click', handleDeleteProduct);
            });
        }
    }

    async function handleLogout(event) {
        event.preventDefault();
        const result = await fetchData('api/auth.php?action=logout');
        if (result?.success) {
            redirectToLogin();
        } else {
            showMessageBox('Logout failed.', 'error');
        }
    }
});
