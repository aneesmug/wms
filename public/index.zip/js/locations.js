// public/js/locations.js

document.addEventListener('DOMContentLoaded', () => {
    // --- DOM Elements ---
    const locationForm = document.getElementById('locationForm');
    const locationFormTitle = document.getElementById('locationFormTitle');
    const locationIdInput = document.getElementById('locationId');
    const locationsTableBody = document.getElementById('locationsTableBody');
    const saveLocationBtn = document.getElementById('saveLocationBtn');
    const cancelEditBtn = document.getElementById('cancelEditBtn');
    const logoutBtn = document.getElementById('logoutBtn');

    // --- Form Fields ---
    const locationCodeInput = document.getElementById('locationCode');
    const locationTypeSelect = document.getElementById('locationType');
    const maxCapacityUnitsInput = document.getElementById('maxCapacityUnits');
    const maxCapacityWeightInput = document.getElementById('maxCapacityWeight');
    const maxCapacityVolumeInput = document.getElementById('maxCapacityVolume');
    const isActiveCheckbox = document.getElementById('isActive');

    // --- Get Current User's Role from localStorage ---
    const currentWarehouseRole = localStorage.getItem('current_warehouse_role');

    // --- Event Listeners ---
    if (locationForm) {
        locationForm.addEventListener('submit', handleSaveLocation);
    }
    if (cancelEditBtn) {
        cancelEditBtn.addEventListener('click', resetLocationForm);
    }
    if (logoutBtn) {
        logoutBtn.addEventListener('click', (event) => {
            event.preventDefault();
            handleLogout();
        });
    }

    // --- Initial Page Load ---
    initializePage();

    // --- Core Functions ---

    /**
     * Initializes the page, checking for a warehouse and setting UI visibility based on the user's role.
     */
    async function initializePage() {
        if (!currentWarehouseId) {
            showMessageBox('Please select a warehouse on the Dashboard to manage locations.', 'warning', 5000);
            locationsTableBody.innerHTML = `<tr><td colspan="8" class="px-6 py-4 text-center">Please select a warehouse on the Dashboard.</td></tr>`;
            if (locationForm) locationForm.style.display = 'none'; // Hide the form completely
            return;
        }

        // Determine if the user has permission to manage locations (create/edit)
        const canManage = currentWarehouseRole === 'operator' || currentWarehouseRole === 'manager';
        
        if (locationForm) {
            if (canManage) {
                locationForm.style.display = 'grid'; // Show form
            } else {
                locationForm.style.display = 'none'; // Hide form for viewers
                showMessageBox('You have view-only permissions for locations in this warehouse.', 'info', 4000);
            }
        }
        
        await loadLocations();
    }

    /**
     * Fetches location data from the API and populates the table.
     * Action buttons are rendered based on the user's role.
     */
    async function loadLocations() {
        if (!locationsTableBody || !currentWarehouseId) return;

        locationsTableBody.innerHTML = `<tr><td colspan="8" class="px-6 py-4 text-center">Loading locations...</td></tr>`;

        // The backend uses the session to get the warehouse_id, so we don't need to pass it here.
        const response = await fetchData('api/locations.php');

        locationsTableBody.innerHTML = ''; // Clear table
        
        if (response && response.success && Array.isArray(response.data)) {
            if (response.data.length === 0) {
                locationsTableBody.innerHTML = `<tr><td colspan="8" class="px-6 py-4 text-center">No locations found for this warehouse.</td></tr>`;
                return;
            }

            // Define permissions once
            const canEdit = currentWarehouseRole === 'operator' || currentWarehouseRole === 'manager';
            const canDelete = currentWarehouseRole === 'manager';

            response.data.forEach(location => {
                const row = document.createElement('tr');
                const fullnessClass = location.is_full ? 'bg-red-100 text-red-800' : '';
                
                let actionsHtml = '';
                if (canEdit) {
                    actionsHtml += `<button data-id="${location.location_id}" class="edit-btn text-indigo-600 hover:text-indigo-900 mr-3">Edit</button>`;
                }
                if (canDelete) {
                    actionsHtml += `<button data-id="${location.location_id}" class="delete-btn text-red-600 hover:text-red-900">Delete</button>`;
                }
                if (!actionsHtml) {
                    actionsHtml = `<span class="text-gray-500">View Only</span>`;
                }

                row.innerHTML = `
                    <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">${location.location_code}</td>
                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">${location.location_type}</td>
                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">${location.max_capacity_units || 'N/A'}</td>
                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">${location.occupied_capacity || '0'}</td>
                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500 ${fullnessClass}">
                        ${location.available_capacity !== null ? location.available_capacity : 'N/A'}
                    </td>
                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">${location.is_full ? 'Yes' : 'No'}</td>
                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">${location.is_active == 1 ? 'Yes' : 'No'}</td>
                    <td class="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">${actionsHtml}</td>
                `;
                locationsTableBody.appendChild(row);
            });
            
            addTableButtonListeners();

        } else {
            locationsTableBody.innerHTML = `<tr><td colspan="8" class="px-6 py-4 text-center">Error loading locations.</td></tr>`;
            showMessageBox(response?.message || "Failed to load locations from server.", 'error');
        }
    }

    /**
     * Handles the form submission for both creating and updating a location.
     */
    async function handleSaveLocation(event) {
        event.preventDefault();
        
        const data = {
            location_id: locationIdInput.value || null,
            location_code: locationCodeInput.value.trim(),
            location_type: locationTypeSelect.value,
            max_capacity_units: maxCapacityUnitsInput.value.trim() || null,
            max_capacity_weight: maxCapacityWeightInput.value.trim() || null,
            max_capacity_volume: maxCapacityVolumeInput.value.trim() || null,
            is_active: isActiveCheckbox.checked,
        };

        if (!data.location_code) {
            showMessageBox('Location Code is required.', 'error');
            return;
        }

        const isUpdating = !!data.location_id;
        const method = isUpdating ? 'PUT' : 'POST';
        
        saveLocationBtn.disabled = true;
        saveLocationBtn.innerHTML = 'Saving...';

        const result = await fetchData('api/locations.php', method, data);
        
        if (result && result.success) {
            showMessageBox(result.message, 'success');
            resetLocationForm();
            await loadLocations();
        }

        saveLocationBtn.disabled = false;
        saveLocationBtn.textContent = isUpdating ? 'Update Location' : 'Save Location';
    }

    /**
     * Populates the form with data for editing a location when an 'Edit' button is clicked.
     */
    async function handleEditClick(event) {
        const id = event.target.dataset.id;
        const response = await fetchData(`api/locations.php?id=${id}`);
        if (response && response.success) {
            const loc = response.data;
            locationIdInput.value = loc.location_id;
            locationCodeInput.value = loc.location_code;
            locationTypeSelect.value = loc.location_type;
            maxCapacityUnitsInput.value = loc.max_capacity_units;
            maxCapacityWeightInput.value = loc.max_capacity_weight;
            maxCapacityVolumeInput.value = loc.max_capacity_volume;
            isActiveCheckbox.checked = !!parseInt(loc.is_active);

            locationFormTitle.textContent = 'Edit Location';
            saveLocationBtn.textContent = 'Update Location';
            cancelEditBtn.style.display = 'inline-flex';
            window.scrollTo({ top: 0, behavior: 'smooth' });
        } else {
            showMessageBox(response?.message || 'Failed to load location for editing.', 'error');
        }
    }

    /**
     * Handles the deletion of a location when a 'Delete' button is clicked.
     */
    async function handleDeleteClick(event) {
        const id = event.target.dataset.id;
        if (confirm('Are you sure you want to delete this location? This action cannot be undone.')) {
            const result = await fetchData(`api/locations.php?id=${id}`, 'DELETE');
            if (result && result.success) {
                showMessageBox('Location deleted successfully!', 'success');
                await loadLocations();
                resetLocationForm(); // Reset form in case the deleted item was being edited
            }
        }
    }

    /**
     * Resets the form to its default "Add New" state.
     */
    function resetLocationForm() {
        locationForm.reset();
        locationIdInput.value = '';
        isActiveCheckbox.checked = true;
        locationFormTitle.textContent = 'Add New Location';
        saveLocationBtn.textContent = 'Save Location';
        cancelEditBtn.style.display = 'none';
    }
    
    /**
     * Attaches event listeners to the dynamically generated Edit and Delete buttons.
     */
    function addTableButtonListeners() {
        document.querySelectorAll('.edit-btn').forEach(button => {
            button.addEventListener('click', handleEditClick);
        });
        document.querySelectorAll('.delete-btn').forEach(button => {
            button.addEventListener('click', handleDeleteClick);
        });
    }

    /**
     * Handles the user logout process.
     */
    async function handleLogout() {
        const result = await fetchData('api/auth.php?action=logout');
        if (result && result.success) {
            showMessageBox('Logged out successfully.', 'success');
            redirectToLogin();
        } else {
            showMessageBox('Logout failed.', 'error');
        }
    }
});
