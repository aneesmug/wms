document.addEventListener('DOMContentLoaded', () => {
    // --- DOM Elements ---
    const createOrderForm = document.getElementById('createOrderForm');
    const customerSelect = document.getElementById('customerSelect');
    const outboundOrdersTableBody = document.getElementById('outboundOrdersTableBody');
    const selectedOrderNumberDisplay = document.getElementById('selectedOrderNumberDisplay');
    const orderProcessingArea = document.getElementById('orderProcessingArea');
    const currentOrderIdInput = document.getElementById('currentOrderId');
    const orderItemsTableBody = document.getElementById('orderItemsTableBody');
    const pickBarcodeInput = document.getElementById('pickBarcodeInput');
    const pickLocationSelect = document.getElementById('pickLocationSelect');
    const pickQuantityInput = document.getElementById('pickQuantityInput');
    const pickBatchNumberInput = document.getElementById('pickBatchNumberInput');
    const pickItemBtn = document.getElementById('pickItemBtn');
    const shipOrderBtn = document.getElementById('shipOrderBtn');
    const logoutBtn = document.getElementById('logoutBtn');
    const addProductSelect = document.getElementById('addProductSelect');
    const addItemToOrderBtn = document.getElementById('addItemToOrderBtn');
    
    // Section Wrappers for role-based visibility
    const createOrderSection = document.getElementById('createOrderSection');
    const addItemSection = document.getElementById('addItemSection');

    // --- State Variables ---
    let selectedOrderId = null;
    let allProducts = [];

    // Get user's role for the current warehouse from localStorage
    const currentWarehouseRole = localStorage.getItem('current_warehouse_role');

    // --- Initialize Page ---
    initializePage();

    // --- Event Listeners ---
    if (createOrderForm) createOrderForm.addEventListener('submit', handleCreateOrder);
    if (addItemToOrderBtn) addItemToOrderBtn.addEventListener('click', handleAddItemToOrder);
    if (pickItemBtn) pickItemBtn.addEventListener('click', handlePickItem);
    if (shipOrderBtn) shipOrderBtn.addEventListener('click', handleShipOrder);
    if (logoutBtn) logoutBtn.addEventListener('click', handleLogout);

    if (pickBarcodeInput) {
        pickBarcodeInput.addEventListener('input', () => {
            filterPickLocationsByProduct(pickBarcodeInput.value.trim());
        });
        // Assuming setupBarcodeScanner is defined in another script
        // setupBarcodeScanner('pickBarcodeInput', (barcode) => {
        //     pickBarcodeInput.value = barcode;
        //     filterPickLocationsByProduct(barcode);
        // });
    }

    // --- Core Functions ---

    /**
     * Initializes the page, sets UI visibility based on role, and loads initial data.
     */
    async function initializePage() {
        if (!currentWarehouseId) {
            showMessageBox('Please select a warehouse on the Dashboard to enable outbound operations.', 'warning', 5000);
            outboundOrdersTableBody.innerHTML = `<tr><td colspan="6" class="px-6 py-4 text-center">Please select a warehouse first.</td></tr>`;
            // Hide all functional sections if no warehouse is selected
            [createOrderSection, orderProcessingArea, addItemSection].forEach(section => {
                if(section) section.style.display = 'none';
            });
            return;
        }

        const canManageOutbound = currentWarehouseRole === 'operator' || currentWarehouseRole === 'manager';

        // Set visibility of management sections based on user role
        if (createOrderSection) createOrderSection.style.display = canManageOutbound ? 'block' : 'none';
        if (orderProcessingArea) orderProcessingArea.style.display = canManageOutbound ? 'block' : 'none';
        if (addItemSection) addItemSection.style.display = canManageOutbound ? 'block' : 'none';

        if (!canManageOutbound) {
            // Hide the entire processing area for viewers to avoid confusion
            if(orderProcessingArea) orderProcessingArea.style.display = 'none';
            showMessageBox("You have view-only permissions for outbound operations.", "info", 4000);
        }

        await Promise.all([
            loadCustomersForDropdown(),
            loadProductsForDropdown(),
            loadOutboundOrders()
        ]);
    }

    async function loadCustomersForDropdown() {
        if (!customerSelect) return;
        const response = await fetchData('api/customers.php');
        customerSelect.innerHTML = '<option value="">Select a Customer</option>';
        if (response?.success && Array.isArray(response.data)) {
            response.data.forEach(customer => {
                customerSelect.add(new Option(customer.customer_name, customer.customer_id));
            });
        }
    }

    async function loadProductsForDropdown() {
        if (!addProductSelect) return;
        const response = await fetchData('api/products.php');
        addProductSelect.innerHTML = '<option value="">Select Product</option>';
        if (response?.success && Array.isArray(response.data)) {
            allProducts = response.data;
            allProducts.forEach(product => {
                addProductSelect.add(new Option(`${product.sku} - ${product.product_name}`, product.product_id));
            });
        }
    }

    async function filterPickLocationsByProduct(productBarcode) {
        if (!pickLocationSelect) return;
        pickLocationSelect.innerHTML = '<option value="">Enter product barcode first.</option>';
        if (!productBarcode) return;

        pickLocationSelect.innerHTML = '<option value="">Loading locations...</option>';
        
        const response = await fetchData(`api/inventory.php?barcode=${encodeURIComponent(productBarcode)}`);
        
        if (response?.success && Array.isArray(response.data) && response.data.length > 0) {
            pickLocationSelect.innerHTML = '<option value="">Select a Pick Location</option>';
            response.data.forEach(inventoryItem => {
                pickLocationSelect.add(new Option(`${inventoryItem.location_code} - ${inventoryItem.quantity} units (Batch: ${inventoryItem.batch_number || 'N/A'})`, inventoryItem.location_id));
            });
        } else {
            pickLocationSelect.innerHTML = '<option value="">No stock found for this product.</option>';
        }
    }

    async function loadOutboundOrders() {
        if (!outboundOrdersTableBody) return;
        outboundOrdersTableBody.innerHTML = `<tr><td colspan="6" class="px-6 py-4 text-center">Loading orders...</td></tr>`;
        const response = await fetchData('api/outbound.php');
        outboundOrdersTableBody.innerHTML = '';

        if (response?.success && Array.isArray(response.data)) {
            if(response.data.length === 0){
                outboundOrdersTableBody.innerHTML = `<tr><td colspan="6" class="px-6 py-4 text-center">No outbound orders found.</td></tr>`;
                return;
            }
            const canManageOutbound = currentWarehouseRole === 'operator' || currentWarehouseRole === 'manager';

            response.data.forEach(order => {
                const row = outboundOrdersTableBody.insertRow();
                const statusClass = order.status === 'Shipped' ? 'bg-green-100 text-green-800' :
                                    order.status === 'Picked' ? 'bg-blue-100 text-blue-800' :
                                    order.status === 'Partially Picked' ? 'bg-orange-100 text-orange-800' :
                                    'bg-yellow-100 text-yellow-800';
                
                let selectButtonHtml = '';
                if (order.status !== 'Shipped' && order.status !== 'Cancelled' && canManageOutbound) {
                    selectButtonHtml = `<button data-order-id="${order.order_id}" data-order-number="${order.order_number}" class="select-order-btn text-indigo-600 hover:text-indigo-900 mr-2">Select</button>`;
                }

                row.innerHTML = `
                    <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">${order.order_number}</td>
                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">${order.customer_name || 'N/A'}</td>
                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">${order.required_ship_date}</td>
                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500"><span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${statusClass}">${order.status}</span></td>
                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">${order.warehouse_name || 'N/A'}</td>
                    <td class="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                        ${selectButtonHtml}
                        <button data-order-id="${order.order_id}" class="view-details-btn text-blue-600 hover:text-blue-900">Details</button>
                    </td>
                `;
            });
            addTableButtonListeners();
        } else {
            outboundOrdersTableBody.innerHTML = `<tr><td colspan="6" class="px-6 py-4 text-center">Error loading orders.</td></tr>`;
        }
    }

    async function loadOrderItems(orderId) {
        if (!orderItemsTableBody) return;
        orderItemsTableBody.innerHTML = `<tr><td colspan="7" class="text-center p-4">Loading items...</td></tr>`;
        const response = await fetchData(`api/outbound.php?order_id=${orderId}`);
        orderItemsTableBody.innerHTML = '';
        if (response?.success && Array.isArray(response.data.items)) {
            if(response.data.items.length === 0){
                orderItemsTableBody.innerHTML = `<tr><td colspan="7" class="text-center p-4">No items have been added to this order yet.</td></tr>`;
                return;
            }
            response.data.items.forEach(item => {
                const row = orderItemsTableBody.insertRow();
                row.innerHTML = `
                    <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">${item.sku}</td>
                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">${item.product_name}</td>
                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">${item.ordered_quantity}</td>
                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">${item.picked_quantity}</td>
                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">${item.batch_number || 'N/A'}</td>
                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">${item.picked_from_location_code || 'Not Picked'}</td>
                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">${item.status || 'Pending'}</td>
                `;
            });
        }
    }
    
    function addTableButtonListeners() {
        document.querySelectorAll('.select-order-btn').forEach(button => {
            button.addEventListener('click', (event) => {
                const { orderId, orderNumber } = event.target.dataset;
                selectedOrderId = orderId;
                currentOrderIdInput.value = selectedOrderId;
                selectedOrderNumberDisplay.textContent = `(Order: ${orderNumber})`;
                if(orderProcessingArea) orderProcessingArea.classList.remove('hidden');
                loadOrderItems(selectedOrderId);
                [pickBarcodeInput, pickLocationSelect, pickBatchNumberInput].forEach(input => input.value = '');
                pickQuantityInput.value = '1';
                showMessageBox(`Selected Order: ${orderNumber}`, 'info');
            });
        });
        document.querySelectorAll('.view-details-btn').forEach(button => {
            button.addEventListener('click', (event) => {
                const orderId = event.target.dataset.orderId;
                loadOrderItems(orderId);
                const orderNumber = button.closest('tr').querySelector('td').textContent;
                selectedOrderNumberDisplay.textContent = `(Details for Order: ${orderNumber})`;
                 if(orderProcessingArea) orderProcessingArea.classList.remove('hidden');
            });
        });
    }

    async function handleCreateOrder(event) {
        event.preventDefault();
        const data = {
            order_number: document.getElementById('orderNumber').value.trim(),
            customer_id: customerSelect.value,
            required_ship_date: document.getElementById('requiredShipDate').value
        };
        if (!data.order_number || !data.customer_id || !data.required_ship_date) {
            showMessageBox('Order Number, Customer, and Ship Date are required.', 'error');
            return;
        }
        const result = await fetchData('api/outbound.php?action=createOrder', 'POST', data);
        if (result?.success) {
            showMessageBox('Order created successfully!', 'success');
            createOrderForm.reset();
            await loadOutboundOrders();
        }
    }

    async function handleAddItemToOrder() {
        if (!selectedOrderId) {
            showMessageBox('Please select an order first.', 'error');
            return;
        }
        const selectedProduct = allProducts.find(p => p.product_id == addProductSelect.value);
        if (!selectedProduct) {
            showMessageBox('Please select a valid product.', 'error');
            return;
        }
        const data = {
            order_id: selectedOrderId,
            product_barcode: selectedProduct.barcode,
            ordered_quantity: parseInt(document.getElementById('addQuantityInput').value, 10)
        };
        if (!data.product_barcode || isNaN(data.ordered_quantity) || data.ordered_quantity <= 0) {
            showMessageBox('A valid product and quantity are required.', 'error');
            return;
        }
        const result = await fetchData('api/outbound.php?action=addItem', 'POST', data);
        if (result?.success) {
            showMessageBox('Item added to order successfully!', 'success');
            addProductSelect.value = '';
            document.getElementById('addQuantityInput').value = '1';
            await loadOrderItems(selectedOrderId);
        }
    }

    async function handlePickItem() {
        if (!selectedOrderId) {
            showMessageBox('Please select an order first.', 'error');
            return;
        }
        const data = {
            order_id: selectedOrderId,
            product_barcode: pickBarcodeInput.value.trim(),
            location_id: pickLocationSelect.value,
            picked_quantity: parseInt(pickQuantityInput.value, 10),
            batch_number: pickBatchNumberInput.value.trim() || null
        };
        if (!data.product_barcode || !data.location_id || isNaN(data.picked_quantity) || data.picked_quantity <= 0) {
            showMessageBox('Product, Location, and a valid Quantity are required to pick.', 'error');
            return;
        }
        const result = await fetchData('api/outbound.php?action=pickItem', 'POST', data);
        if (result?.success) {
            showMessageBox(result.message, 'success');
            const pickedBarcode = pickBarcodeInput.value.trim();
            [pickBarcodeInput, pickLocationSelect, pickBatchNumberInput].forEach(input => input.value = '');
            pickQuantityInput.value = '1';
            await Promise.all([
                loadOrderItems(selectedOrderId), 
                loadOutboundOrders(), 
                filterPickLocationsByProduct(pickedBarcode) // Refresh locations for the just-picked item
            ]);
        }
    }

    async function handleShipOrder() {
        if (!selectedOrderId) {
            showMessageBox('Please select an order to ship.', 'error');
            return;
        }
        if (!confirm('Are you sure you want to ship this order?')) {
            return;
        }
        const result = await fetchData('api/outbound.php?action=shipOrder', 'POST', { order_id: selectedOrderId });
        if (result?.success) {
            showMessageBox('Order successfully shipped.', 'success');
            selectedOrderId = null;
            currentOrderIdInput.value = '';
            selectedOrderNumberDisplay.textContent = 'None Selected';
            if(orderProcessingArea) orderProcessingArea.classList.add('hidden');
            orderItemsTableBody.innerHTML = '';
            await loadOutboundOrders();
        }
    }

    async function handleLogout() {
        const result = await fetchData('api/auth.php?action=logout');
        if (result?.success) {
            redirectToLogin();
        } else {
            showMessageBox('Logout failed.', 'error');
        }
    }
});
