// public/js/inbound.js

// Global variables currentWarehouseId and currentWarehouseName are assumed to be available from main.js

document.addEventListener('DOMContentLoaded', () => {
    // --- DOM Elements ---
    const receiveShipmentForm = document.getElementById('receiveShipmentForm');
    const inboundReceiptsTableBody = document.getElementById('inboundReceiptsTableBody');
    const logoutBtn = document.getElementById('logoutBtn');

    // Section wrappers for role-based visibility
    const createReceiptSection = document.getElementById('createReceiptSection'); // Assuming a wrapper div/section
    const receivePutawaySection = document.getElementById('receivePutawaySection'); // Assuming a wrapper div/section

    // Receiving/Putaway elements
    const productSelectDropdown = document.getElementById('productSelectDropdown');
    const scanBarcodeInput = document.getElementById('scanBarcodeInput');
    const itemQuantityInput = document.getElementById('itemQuantity');
    const inboundBatchNumberInput = document.getElementById('inboundBatchNumber');
    const inboundExpiryDateInput = document.getElementById('inboundExpiryDate');
    const locationSelectDropdown = document.getElementById('locationSelectDropdown');
    const scanLocationInput = document.getElementById('scanLocationInput');
    const receiveItemBtn = document.getElementById('receiveItemBtn');
    const putawayItemBtn = document.getElementById('putawayItemBtn');
    const supplierSelect = document.getElementById('supplierSelect');

    const selectedReceiptDisplay = document.getElementById('selectedReceiptDisplay');

    // --- State Variables ---
    let currentReceiptId = null;
    let allProducts = [];
    let allLocations = [];
    
    // Get user's role for the current warehouse
    const currentWarehouseRole = localStorage.getItem('current_warehouse_role');

    // Initialize the page
    initializePage();

    // --- Event Listeners ---
    if (receiveShipmentForm) {
        receiveShipmentForm.addEventListener('submit', handleCreateReceipt);
    }
    if (logoutBtn) {
        logoutBtn.addEventListener('click', handleLogout);
    }
    if (receiveItemBtn) {
        receiveItemBtn.addEventListener('click', handleReceiveItem);
    }
    if (putawayItemBtn) {
        putawayItemBtn.addEventListener('click', handlePutawayItem);
    }
    if (productSelectDropdown) {
        productSelectDropdown.addEventListener('change', (event) => {
            const selectedProduct = allProducts.find(p => p.product_id == event.target.value);
            scanBarcodeInput.value = selectedProduct ? selectedProduct.barcode : '';
        });
    }
    if (locationSelectDropdown) {
        locationSelectDropdown.addEventListener('change', (event) => {
            const selectedLocation = allLocations.find(l => l.location_id == event.target.value);
            scanLocationInput.value = selectedLocation ? selectedLocation.location_code : '';
        });
    }

    // Barcode scanner setup
    if (scanBarcodeInput) {
        setupBarcodeScanner('scanBarcodeInput', (barcode) => {
            scanBarcodeInput.value = barcode;
            const matchingProduct = allProducts.find(p => p.barcode === barcode);
            if (matchingProduct) {
                productSelectDropdown.value = matchingProduct.product_id;
                showMessageBox(`Product scanned: ${matchingProduct.product_name}`, 'info');
            } else {
                showMessageBox(`Product barcode not found: ${barcode}`, 'warning');
            }
        });
    }
    if (scanLocationInput) {
        setupBarcodeScanner('scanLocationInput', (barcode) => {
            scanLocationInput.value = barcode;
            const matchingLocation = allLocations.find(l => l.location_code === barcode);
            if (matchingLocation) {
                locationSelectDropdown.value = matchingLocation.location_id;
                showMessageBox(`Location scanned: ${matchingLocation.location_code}`, 'info');
            } else {
                showMessageBox(`Location barcode not found: ${barcode}`, 'warning');
            }
        });
    }

    // --- Core Functions ---

    /**
     * Initializes the page, sets UI visibility based on role, and loads initial data.
     */
    async function initializePage() {
        if (!currentWarehouseId) {
            showMessageBox('Please select a warehouse on the Dashboard to enable inbound operations.', 'warning', 5000);
            inboundReceiptsTableBody.innerHTML = `<tr><td colspan="6" class="px-6 py-4 text-center">Please select a warehouse first.</td></tr>`;
            // Disable all forms and inputs
            [createReceiptSection, receivePutawaySection].forEach(section => {
                if(section) section.style.display = 'none';
            });
            return;
        }

        // Role-based UI control
        const canManageInbound = currentWarehouseRole === 'operator' || currentWarehouseRole === 'manager';

        if (createReceiptSection) {
            createReceiptSection.style.display = canManageInbound ? 'block' : 'none';
        }
        if (receivePutawaySection) {
            receivePutawaySection.style.display = canManageInbound ? 'block' : 'none';
        }
        if (!canManageInbound) {
            showMessageBox("You have view-only permissions for inbound operations.", "info");
        }
        
        // Load data needed for the page
        await Promise.all([
            loadSuppliersForDropdown(),
            loadProductsForDropdown(),
            loadLocationsForDropdown(currentWarehouseId),
            loadInboundReceipts()
        ]);
    }

    /**
     * Loads suppliers into the 'Create Receipt' form dropdown.
     */
    async function loadSuppliersForDropdown() {
        if (!supplierSelect) return;
        const suppliers = await fetchData('api/suppliers.php');
        supplierSelect.innerHTML = '<option value="">Select Supplier</option>';
        if (suppliers && suppliers.success && Array.isArray(suppliers.data)) {
            suppliers.data.forEach(supplier => {
                const option = document.createElement('option');
                option.value = supplier.supplier_id;
                option.textContent = supplier.supplier_name;
                supplierSelect.appendChild(option);
            });
        }
    }
    
    /**
     * Loads products into the 'Receive/Putaway' form dropdown.
     */
    async function loadProductsForDropdown() {
        if (!productSelectDropdown) return;
        const products = await fetchData('api/products.php');
        productSelectDropdown.innerHTML = '<option value="">Select a Product</option>';
        if (products && products.success && Array.isArray(products.data)) {
            allProducts = products.data;
            allProducts.forEach(product => {
                const option = document.createElement('option');
                option.value = product.product_id;
                option.textContent = `${product.sku} - ${product.product_name}`;
                productSelectDropdown.appendChild(option);
            });
        }
    }
    
    /**
     * Loads available (not full) locations into the 'Putaway' form dropdown.
     */
    async function loadLocationsForDropdown(warehouseId) {
        if (!locationSelectDropdown) return;
        const locations = await fetchData(`api/locations.php`);
        locationSelectDropdown.innerHTML = '<option value="">Select Location</option>';
        if (locations && locations.success && Array.isArray(locations.data)) {
            allLocations = locations.data;
            const availableLocations = allLocations.filter(loc => loc.is_active && !loc.is_full);
            availableLocations.forEach(location => {
                let capacityText = location.max_capacity_units ? `(${location.occupied_capacity}/${location.max_capacity_units})` : '(No Limit)';
                const option = document.createElement('option');
                option.value = location.location_id;
                option.textContent = `${location.location_code} ${capacityText}`;
                locationSelectDropdown.appendChild(option);
            });
        }
    }
    
    /**
     * Loads the list of inbound receipts and renders them in the table.
     */
    async function loadInboundReceipts() {
        if (!inboundReceiptsTableBody) return;
        inboundReceiptsTableBody.innerHTML = `<tr><td colspan="6" class="px-6 py-4 text-center">Loading...</td></tr>`;
        
        const response = await fetchData('api/inbound.php');
        inboundReceiptsTableBody.innerHTML = '';
        
        if (response && response.success && Array.isArray(response.data)) {
            if(response.data.length === 0) {
                inboundReceiptsTableBody.innerHTML = `<tr><td colspan="6" class="px-6 py-4 text-center">No inbound receipts found.</td></tr>`;
                return;
            }

            const canManageInbound = currentWarehouseRole === 'operator' || currentWarehouseRole === 'manager';

            response.data.forEach(receipt => {
                const row = document.createElement('tr');
                const statusClass = receipt.status === 'Completed' ? 'bg-green-100 text-green-800' :
                                    receipt.status === 'Received' ? 'bg-blue-100 text-blue-800' :
                                    'bg-yellow-100 text-yellow-800';
                
                let selectButtonHtml = '';
                if (receipt.status !== 'Completed' && canManageInbound) {
                    selectButtonHtml = `<button data-receipt-id="${receipt.receipt_id}" data-receipt-number="${receipt.receipt_number}" data-supplier-name="${receipt.supplier_name || ''}" class="select-receipt-btn text-indigo-600 hover:text-indigo-900 mr-2">Select</button>`;
                }

                row.innerHTML = `
                    <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">${receipt.receipt_number}</td>
                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">${receipt.supplier_name || 'N/A'}</td>
                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">${receipt.expected_arrival_date}</td>
                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500"><span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${statusClass}">${receipt.status}</span></td>
                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">${receipt.warehouse_name || 'N/A'}</td>
                    <td class="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                        ${selectButtonHtml}
                        <button data-receipt-id="${receipt.receipt_id}" class="view-details-btn text-blue-600 hover:text-blue-900">Details</button>
                    </td>
                `;
                inboundReceiptsTableBody.appendChild(row);
            });
            
            addTableButtonListeners();
        } else {
             inboundReceiptsTableBody.innerHTML = `<tr><td colspan="6" class="px-6 py-4 text-center">Error loading receipts.</td></tr>`;
        }
    }

    /**
     * Adds event listeners to dynamically created buttons in the receipts table.
     */
    function addTableButtonListeners() {
        document.querySelectorAll('.select-receipt-btn').forEach(button => {
            button.addEventListener('click', (event) => {
                currentReceiptId = event.target.dataset.receiptId;
                const receiptNumber = event.target.dataset.receiptNumber;
                const supplierName = event.target.dataset.supplierName;
                if (selectedReceiptDisplay) {
                    selectedReceiptDisplay.textContent = `(Receipt: ${receiptNumber}, Supplier: ${supplierName})`;
                }
                showMessageBox(`Selected receipt: ${receiptNumber}`, 'info');
                // Reset fields
                scanBarcodeInput.value = '';
                itemQuantityInput.value = '1';
                inboundBatchNumberInput.value = '';
                inboundExpiryDateInput.value = '';
                scanLocationInput.value = '';
                productSelectDropdown.value = '';
                locationSelectDropdown.value = '';
            });
        });
        document.querySelectorAll('.view-details-btn').forEach(button => {
            button.addEventListener('click', (event) => {
                // Future functionality: show modal with receipt details.
                showMessageBox(`Viewing details for receipt ID: ${event.target.dataset.receiptId}`, 'info');
            });
        });
    }

    /**
     * Handles creation of a new inbound receipt.
     */
    async function handleCreateReceipt(event) {
        event.preventDefault();
        const data = {
            receipt_number: document.getElementById('receiptNumber').value.trim(),
            supplier_id: supplierSelect.value,
            expected_arrival_date: document.getElementById('expectedArrivalDate').value
        };
        if (!data.receipt_number || !data.supplier_id || !data.expected_arrival_date) {
            showMessageBox('All fields are required to create a receipt.', 'error');
            return;
        }

        const result = await fetchData('api/inbound.php?action=createReceipt', 'POST', data);
        if (result && result.success) {
            showMessageBox('Receipt created successfully!', 'success');
            receiveShipmentForm.reset();
            await loadInboundReceipts();
        }
    }

    /**
     * Handles receiving an item against the currently selected receipt.
     */
    async function handleReceiveItem() {
        if (!currentReceiptId) {
            showMessageBox('Please select a receipt first.', 'error');
            return;
        }
        const data = {
            receipt_id: currentReceiptId,
            barcode: scanBarcodeInput.value.trim(),
            received_quantity: parseInt(itemQuantityInput.value, 10),
            batch_number: inboundBatchNumberInput.value.trim() || null,
            expiry_date: inboundExpiryDateInput.value.trim() || null
        };
        if (!data.barcode || isNaN(data.received_quantity) || data.received_quantity <= 0) {
            showMessageBox('Product barcode and a valid quantity are required.', 'error');
            return;
        }

        const result = await fetchData('api/inbound.php?action=receiveItem', 'POST', data);
        if (result && result.success) {
            showMessageBox('Item successfully received.', 'success');
            // Reset fields for next item
            scanBarcodeInput.value = '';
            itemQuantityInput.value = '1';
            inboundBatchNumberInput.value = result.generated_batch_number || '';
            inboundExpiryDateInput.value = '';
            productSelectDropdown.value = '';
            // Refresh data
            await loadInboundReceipts();
        }
    }
    
    /**
     * Handles putting away a received item to a final location.
     */
    async function handlePutawayItem() {
        if (!currentReceiptId) {
            showMessageBox('Please select a receipt first.', 'error');
            return;
        }
        const data = {
            receipt_id: currentReceiptId,
            barcode: scanBarcodeInput.value.trim(),
            location_barcode: scanLocationInput.value.trim(),
            putaway_quantity: parseInt(itemQuantityInput.value, 10),
            batch_number: inboundBatchNumberInput.value.trim() || null
        };
        if (!data.barcode || !data.location_barcode || isNaN(data.putaway_quantity) || data.putaway_quantity <= 0) {
            showMessageBox('Product, Location, and a valid Quantity are required.', 'error');
            return;
        }
        
        const result = await fetchData('api/inbound.php?action=putawayItem', 'POST', data);
        if (result && result.success) {
            showMessageBox('Item successfully put away.', 'success');
            // Reset all related fields
            scanBarcodeInput.value = '';
            scanLocationInput.value = '';
            itemQuantityInput.value = '1';
            inboundBatchNumberInput.value = '';
            inboundExpiryDateInput.value = '';
            productSelectDropdown.value = '';
            locationSelectDropdown.value = '';
            // Refresh data
            await Promise.all([loadInboundReceipts(), loadLocationsForDropdown(currentWarehouseId)]);
        }
    }

    /**
     * Handles user logout.
     */
    async function handleLogout() {
        const result = await fetchData('api/auth.php?action=logout');
        if (result && result.success) {
            redirectToLogin();
        } else {
            showMessageBox('Logout failed.', 'error');
        }
    }
});
