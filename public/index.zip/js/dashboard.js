// public/js/dashboard.js

document.addEventListener('DOMContentLoaded', async () => {
    // DOM elements
    const warehouseSelect = document.getElementById('warehouseSelector');
    const welcomeMessageElement = document.getElementById('welcomeMessage');
    const totalProductsElement = document.getElementById('totalProducts');
    const openInboundsElement = document.getElementById('openInbounds');
    const pendingOutboundsElement = document.getElementById('pendingOutbounds');
    const logoutBtn = document.getElementById('logoutBtn');

    // --- 1. Initial Authentication and State Synchronization ---
    const authStatus = await fetchData('api/auth.php?action=check_auth');
    if (!authStatus || !authStatus.authenticated) {
        redirectToLogin();
        return; // Stop execution
    }

    // --- SYNC CLIENT STATE WITH SERVER SESSION ---
    // Update welcome message
    if (welcomeMessageElement && authStatus.user) {
        welcomeMessageElement.textContent = `Welcome, ${authStatus.user.username}!`;
    }

    // Sync global JS variables and localStorage from the session data.
    // This avoids the reload loop caused by calling setCurrentWarehouse on every page load.
    currentWarehouseId = authStatus.current_warehouse_id;
    currentWarehouseName = authStatus.current_warehouse_name;
    currentWarehouseRole = authStatus.current_warehouse_role;

    if (currentWarehouseId) {
        localStorage.setItem('current_warehouse_id', currentWarehouseId);
        localStorage.setItem('current_warehouse_name', currentWarehouseName);
        localStorage.setItem('current_warehouse_role', currentWarehouseRole);
    } else {
        localStorage.removeItem('current_warehouse_id');
        localStorage.removeItem('current_warehouse_name');
        localStorage.removeItem('current_warehouse_role');
    }
    
    // Use the updateWarehouseDisplay() function from main.js to show the current status
    updateWarehouseDisplay();
    // --- END SYNC ---


    // --- 2. Load Page Content ---
    // Now that the state is synced, proceed with loading the rest of the page.
    await loadWarehousesForSelector();
    await loadDashboardSummary();


    // --- 3. Event Listeners ---
    if (logoutBtn) {
        logoutBtn.addEventListener('click', async (event) => {
            event.preventDefault();
            const logoutResult = await fetchData('api/auth.php?action=logout');
            if (logoutResult && logoutResult.success) {
                showMessageBox('Logged out successfully.', 'success');
                redirectToLogin();
            }
        });
    }

    // Warehouse selector change logic. This is the ONLY place setCurrentWarehouse should be called.
    if (warehouseSelect) {
        warehouseSelect.addEventListener('change', async (event) => {
            const selectedOption = event.target.options[event.target.selectedIndex];
            const id = selectedOption.value;
            const name = selectedOption.textContent;

            if (id) {
                // This function handles the API call and reloads the page.
                await setCurrentWarehouse(parseInt(id), name);
            } else {
                // Handle case where user selects the "Select Warehouse" placeholder
                showMessageBox('Please select a warehouse to proceed.', 'warning');
            }
        });
    }


    // --- Helper Functions for Dashboard ---

    /**
     * Fetches and populates the warehouse selector dropdown.
     * It will pre-select the currently active warehouse based on the synced state.
     */
    async function loadWarehousesForSelector() {
        if (!warehouseSelect) return;

        // Fetch warehouses available to the user. This API should return only permitted warehouses.
        const warehouses = await fetchData('api/warehouses.php'); 
        warehouseSelect.innerHTML = '<option value="">Select Warehouse</option>';

        if (warehouses && Array.isArray(warehouses) && warehouses.length > 0) {
            warehouses.forEach(wh => {
                const option = document.createElement('option');
                option.value = wh.warehouse_id;
                option.textContent = wh.warehouse_name;
                
                // Pre-select the option if it matches the globally set currentWarehouseId
                if (currentWarehouseId && wh.warehouse_id == currentWarehouseId) {
                    option.selected = true;
                }
                warehouseSelect.appendChild(option);
            });
        } else if (warehouses && Array.isArray(warehouses)) {
            warehouseSelect.innerHTML = '<option value="">No warehouses assigned</option>';
            warehouseSelect.disabled = true;
        } else {
            warehouseSelect.innerHTML = '<option value="">Error loading warehouses</option>';
            warehouseSelect.disabled = true;
        }
    }

    /**
     * Fetches and updates the dashboard summary data for the current warehouse.
     */
    async function loadDashboardSummary() {
        if (!currentWarehouseId) {
            if (totalProductsElement) totalProductsElement.textContent = 'N/A';
            if (openInboundsElement) openInboundsElement.textContent = 'N/A';
            if (pendingOutboundsElement) pendingOutboundsElement.textContent = 'N/A';
            // No need to show a message here, the warehouse selector makes it clear.
            return;
        }

        const summaryData = await fetchData('api/reports.php?action=dashboardSummary');
        if (summaryData) {
            if (totalProductsElement) totalProductsElement.textContent = summaryData.totalProducts || '0';
            if (openInboundsElement) openInboundsElement.textContent = summaryData.openInbounds || '0';
            if (pendingOutboundsElement) pendingOutboundsElement.textContent = summaryData.pendingOutbounds || '0';
        } else {
            if (totalProductsElement) totalProductsElement.textContent = 'Error';
            if (openInboundsElement) openInboundsElement.textContent = 'Error';
            if (pendingOutboundsElement) pendingOutboundsElement.textContent = 'Error';
        }
    }
});