// public/js/main.js

// Global variables to store current session info, sourced from localStorage
let currentWarehouseId = localStorage.getItem('current_warehouse_id') || null;
let currentWarehouseName = localStorage.getItem('current_warehouse_name') || null;
let currentWarehouseRole = localStorage.getItem('current_warehouse_role') || null;

// Utility function to fetch data from API
async function fetchData(url, method = 'GET', data = null) {
    try {
        const options = {
            method: method,
            headers: {
                'Content-Type': 'application/json',
            },
        };

        // This logic is now handled by the backend session, so we don't need to manually add warehouse_id to requests.
        // The backend's authenticate_user() function will check the session. This simplifies the client-side code.

        if (data) {
            options.body = JSON.stringify(data);
        }

        const response = await fetch(url, options);
        const result = await response.json();

        if (!response.ok) {
            console.error(`API Error: ${response.status} - ${result.message || 'Unknown error'}`);
            showMessageBox(result.message || `An error occurred (Status: ${response.status})`, 'error');

            // If session expired or unauthorized, redirect to login
            if (response.status === 401) {
                setTimeout(redirectToLogin, 1500); 
            }
            // If warehouse selection is required, redirect to dashboard
            else if (response.status === 400 && result.message && result.message.includes('No warehouse selected')) {
                if (!window.location.pathname.includes('dashboard.html')) {
                    setTimeout(redirectToDashboard, 1500);
                }
            }
            return null;
        }
        return result;
    } catch (error) {
        console.error('Network or parsing error:', error);
        showMessageBox('Network error. Please check your internet connection.', 'error');
        return null;
    }
}

// Function to display a custom message box
function showMessageBox(message, type = 'info', duration = 3000) {
    const messageBox = document.getElementById('messageBox');
    const messageText = document.getElementById('messageText');
    if (!messageBox || !messageText) return;

    messageText.textContent = message;
    messageBox.className = `message-box ${type}`;
    messageBox.style.display = 'block';

    setTimeout(() => {
        messageBox.style.display = 'none';
    }, duration);
}

// Function to redirect to login page, clearing all local state
function redirectToLogin() {
    localStorage.removeItem('current_warehouse_id');
    localStorage.removeItem('current_warehouse_name');
    localStorage.removeItem('current_warehouse_role');
    window.location.href = 'index.html';
}

// Function to redirect to dashboard
function redirectToDashboard() {
    window.location.href = 'dashboard.html';
}

/**
 * Sets the current active warehouse by calling the backend.
 * On success, stores info in localStorage and updates the UI.
 * @param {number} id The warehouse_id.
 * @param {string} name The warehouse_name (from the selector).
 * @returns {Promise<boolean>} True on success, false on failure.
 */
async function setCurrentWarehouse(id, name) {
    const result = await fetchData('api/auth.php?action=set_warehouse', 'POST', { warehouse_id: id });

    if (result && result.success) {
        // The backend confirmed access and gave us the role.
        currentWarehouseId = id;
        currentWarehouseName = name;
        currentWarehouseRole = result.role;

        // Store in localStorage for persistence across page loads.
        localStorage.setItem('current_warehouse_id', id);
        localStorage.setItem('current_warehouse_name', name);
        localStorage.setItem('current_warehouse_role', result.role);

        // Update UI.
        updateWarehouseDisplay();
        showMessageBox(`Warehouse selected: ${name}`, 'info');
        
        // Optionally, reload the page or fetch new data to reflect the new context.
        window.location.reload(); // Simple way to refresh all data for the new warehouse.
        return true;
    } else {
        // Error message is already shown by fetchData.
        // Clear local storage to prevent inconsistent state.
        localStorage.removeItem('current_warehouse_id');
        localStorage.removeItem('current_warehouse_name');
        localStorage.removeItem('current_warehouse_role');
        updateWarehouseDisplay(); // Clear the display
        return false;
    }
}

// Helper function to update the warehouse display element
function updateWarehouseDisplay() {
    const displayElement = document.getElementById('currentWarehouseNameDisplay');
    if (displayElement) {
        if (currentWarehouseName && currentWarehouseRole) {
            displayElement.textContent = `Warehouse: ${currentWarehouseName} (Role: ${currentWarehouseRole})`;
        } else if (currentWarehouseName) {
            displayElement.textContent = `Warehouse: ${currentWarehouseName}`;
        } else {
            displayElement.textContent = 'No Warehouse Selected';
        }
    }
}

// Common DOMContentLoaded listener for all pages
document.addEventListener('DOMContentLoaded', () => {
    // Inject the message box HTML if it doesn't exist.
    if (!document.getElementById('messageBox')) {
        document.body.insertAdjacentHTML('afterbegin', `
            <div id="messageBox" class="message-box" style="display:none;">
                <span id="messageText"></span>
                <button onclick="this.parentElement.style.display='none';" style="margin-left: 15px; cursor: pointer; border: none; background: transparent; font-weight: bold;">X</button>
            </div>`);
    }

    // Update the warehouse display on every page load.
    updateWarehouseDisplay();

    // On protected pages, verify auth status with the server to prevent using stale localStorage data.
    const isProtectedPage = !window.location.pathname.endsWith('/') && !window.location.pathname.endsWith('index.html');
    if (isProtectedPage) {
        fetchData('api/auth.php?action=check_auth').then(authStatus => {
            if (!authStatus || !authStatus.authenticated) {
                // This case is handled by fetchData's 401 redirect, but as a fallback:
                redirectToLogin();
            }
        });
    }
});
