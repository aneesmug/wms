// public/js/reports.js

document.addEventListener('DOMContentLoaded', () => {
    const reportTypeSelect = document.getElementById('reportType');
    const startDateInput = document.getElementById('startDate');
    const endDateInput = document.getElementById('endDate');
    const reportProductSearchInput = document.getElementById('reportProductSearch');
    const generateReportBtn = document.getElementById('generateReportBtn');
    const reportTitle = document.getElementById('reportTitle');
    const reportTableHeader = document.getElementById('reportTableHeader');
    const reportTableBody = document.getElementById('reportTableBody');
    const logoutBtn = document.getElementById('logoutBtn');

    // --- Event Listeners ---
    if (generateReportBtn) {
        generateReportBtn.addEventListener('click', generateReport);
    }

    if (logoutBtn) {
        logoutBtn.addEventListener('click', async (event) => {
            event.preventDefault();
            const result = await fetchData('api/auth.php?action=logout');
            if (result && result.success) {
                showMessageBox('Logged out successfully.', 'success');
                redirectToLogin();
            } else {
                showMessageBox('Logout failed.', 'error');
            }
        });
    }

    // --- Functions ---
    async function generateReport() {
        const reportType = reportTypeSelect.value;
        const startDate = startDateInput.value;
        const endDate = endDateInput.value;
        const productSearch = reportProductSearchInput.value;

        let url = `api/reports.php?action=${reportType}`;
        let queryParams = [];

        if (startDate && ['inboundHistory', 'outboundHistory', 'productMovement'].includes(reportType)) {
            queryParams.push(`start_date=${startDate}`);
        }
        if (endDate && ['inboundHistory', 'outboundHistory', 'productMovement'].includes(reportType)) {
            queryParams.push(`end_date=${endDate}`);
        }
        if (productSearch && reportType === 'productMovement') {
            // In a real system, you might want to resolve barcode to product_id first
            queryParams.push(`sku=${encodeURIComponent(productSearch)}`); // Assuming SKU for productMovement
        }

        if (queryParams.length > 0) {
            url += '&' + queryParams.join('&');
        }

        reportTitle.textContent = `Generating ${reportType.replace(/([A-Z])/g, ' $1').trim()} Report...`;
        reportTableHeader.innerHTML = `<tr><th colspan="10" class="px-6 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider">Loading report data...</th></tr>`;
        reportTableBody.innerHTML = '';

        const reportData = await fetchData(url);

        if (reportData) {
            displayReport(reportType, reportData);
        } else {
            reportTableHeader.innerHTML = `<tr><th colspan="10" class="px-6 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider">Failed to load report.</th></tr>`;
        }
    }

    function displayReport(reportType, data) {
        reportTableBody.innerHTML = ''; // Clear previous data

        let headers = [];
        let title = '';

        if (reportType === 'inventorySummary') {
            title = 'Inventory Summary Report';
            headers = ['SKU', 'Product Name', 'Total Quantity', 'Distinct Locations', 'Locations List'];
        } else if (reportType === 'stockByLocation') {
            title = 'Stock By Location Report';
            headers = ['Location Code', 'Location Type', 'SKU', 'Product Name', 'Quantity', 'Batch/Expiry'];
        } else if (reportType === 'inboundHistory') {
            title = 'Inbound History Report';
            headers = ['Receipt No.', 'Supplier', 'Arrival Date', 'Status', 'SKU', 'Product Name', 'Expected Qty', 'Received Qty', 'Putaway Qty', 'Final Location', 'Received By'];
        } else if (reportType === 'outboundHistory') {
            title = 'Outbound History Report';
            headers = ['Order No.', 'Customer', 'Order Date', 'Ship Date', 'Status', 'SKU', 'Product Name', 'Ordered Qty', 'Picked Qty', 'Shipped Qty', 'Picked From', 'Picked By', 'Shipped By'];
        } else if (reportType === 'productMovement') {
            title = 'Product Movement History';
            headers = ['Type', 'Transaction Ref', 'Date', 'Product Name', 'Quantity Change', 'To Location', 'From Location', 'Status', 'Performed By'];
        }

        reportTitle.textContent = title;

        // Populate table header
        reportTableHeader.innerHTML = `
            <tr>
                ${headers.map(header => `<th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">${header}</th>`).join('')}
            </tr>
        `;

        if (data.length === 0) {
            reportTableBody.innerHTML = `<tr><td colspan="${headers.length}" class="px-6 py-4 whitespace-nowrap text-center text-sm text-gray-500">No data found for this report.</td></tr>`;
            return;
        }

        // Populate table body
        data.forEach(row => {
            const tr = document.createElement('tr');
            let rowHtml = '';
            if (reportType === 'inventorySummary') {
                rowHtml = `
                    <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">${row.sku}</td>
                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">${row.product_name}</td>
                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">${row.total_quantity}</td>
                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">${row.distinct_locations}</td>
                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">${row.locations_list}</td>
                `;
            } else if (reportType === 'stockByLocation') {
                rowHtml = `
                    <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">${row.location_code}</td>
                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">${row.location_type}</td>
                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">${row.sku}</td>
                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">${row.product_name}</td>
                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">${row.quantity}</td>
                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">${row.batch_number || 'N/A'}${row.expiry_date ? ` (${row.expiry_date})` : ''}</td>
                `;
            } else if (reportType === 'inboundHistory') {
                rowHtml = `
                    <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">${row.receipt_number}</td>
                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">${row.supplier_name}</td>
                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">${row.actual_arrival_date || 'N/A'}</td>
                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">${row.receipt_status}</td>
                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">${row.sku}</td>
                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">${row.product_name}</td>
                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">${row.expected_quantity}</td>
                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">${row.received_quantity}</td>
                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">${row.putaway_quantity}</td>
                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">${row.final_location || 'Staging'}</td>
                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">${row.received_by_user || 'N/A'}</td>
                `;
            } else if (reportType === 'outboundHistory') {
                rowHtml = `
                    <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">${row.order_number}</td>
                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">${row.customer_name}</td>
                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">${new Date(row.order_date).toLocaleDateString()}</td>
                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">${row.actual_ship_date || 'N/A'}</td>
                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">${row.order_status}</td>
                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">${row.sku}</td>
                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">${row.product_name}</td>
                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">${row.ordered_quantity}</td>
                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">${row.picked_quantity}</td>
                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">${row.shipped_quantity}</td>
                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">${row.picked_from_location || 'N/A'}</td>
                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">${row.picked_by_user || 'N/A'}</td>
                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">${row.shipped_by_user || 'N/A'}</td>
                `;
            } else if (reportType === 'productMovement') {
                rowHtml = `
                    <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">${row.movement_type}</td>
                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">${row.transaction_ref}</td>
                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">${new Date(row.transaction_date).toLocaleDateString()}</td>
                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">${row.product_name}</td>
                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">${row.quantity_change}</td>
                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">${row.to_location || 'N/A'}</td>
                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">${row.from_location || 'N/A'}</td>
                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">${row.status || 'N/A'}</td>
                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">${row.performed_by || 'N/A'}</td>
                `;
            }
            tr.innerHTML = rowHtml;
            reportTableBody.appendChild(tr);
        });
    }
});
