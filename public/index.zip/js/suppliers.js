// public/js/suppliers.js

document.addEventListener('DOMContentLoaded', () => {
    const supplierForm = document.getElementById('supplierForm');
    const supplierFormTitle = document.getElementById('supplierFormTitle');
    const supplierIdInput = document.getElementById('supplierId');
    const suppliersTableBody = document.getElementById('suppliersTableBody');
    const saveSupplierBtn = document.getElementById('saveSupplierBtn');
    const cancelEditBtn = document.getElementById('cancelEditBtn');
    const logoutBtn = document.getElementById('logoutBtn');

    // Form fields
    const supplierNameInput = document.getElementById('supplierName');
    const contactPersonInput = document.getElementById('contactPerson');
    const emailInput = document.getElementById('email');
    const phoneInput = document.getElementById('phone');
    const addressLine1Input = document.getElementById('addressLine1');
    const addressLine2Input = document.getElementById('addressLine2');
    const cityInput = document.getElementById('city');
    const stateInput = document.getElementById('state');
    const zipCodeInput = document.getElementById('zipCode');
    const countryInput = document.getElementById('country');
    const paymentTermsInput = document.getElementById('paymentTerms');
    const taxIdInput = document.getElementById('taxId');
    const isActiveCheckbox = document.getElementById('isActive');


    // --- Event Listeners ---

    if (supplierForm) {
        supplierForm.addEventListener('submit', handleSaveSupplier);
    }

    if (cancelEditBtn) {
        cancelEditBtn.addEventListener('click', resetSupplierForm);
    }

    if (logoutBtn) {
        logoutBtn.addEventListener('click', async (event) => {
            event.preventDefault();
            const result = await fetchData('api/auth.php?action=logout');
            if (result && result.success) {
                showMessageBox('Logged out successfully.', 'success');
                redirectToLogin();
            } else {
                showMessageBox('Logout failed.', 'error');
            }
        });
    }

    // Initial load of suppliers
    loadSuppliers();

    // --- Functions ---

    async function loadSuppliers() {
        if (!suppliersTableBody) return;

        suppliersTableBody.innerHTML = `<tr><td colspan="7" class="px-6 py-4 whitespace-nowrap text-center text-sm text-gray-500">Loading suppliers...</td></tr>`;

        try {
            const suppliersResponse = await fetchData('api/suppliers.php');
            const suppliers = suppliersResponse.data; // Access the data property

            if (suppliers && Array.isArray(suppliers) && suppliers.length > 0) {
                suppliersTableBody.innerHTML = ''; // Clear loading message
                suppliers.forEach(supplier => {
                    const row = document.createElement('tr');
                    row.innerHTML = `
                        <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">${supplier.supplier_name}</td>
                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">${supplier.contact_person || 'N/A'}</td>
                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">${supplier.email || 'N/A'}</td>
                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">${supplier.phone || 'N/A'}</td>
                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">${supplier.city || 'N/A'}</td>
                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">${supplier.is_active == 1 ? 'Yes' : 'No'}</td>
                        <td class="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                            <button data-id="${supplier.supplier_id}" class="edit-btn text-indigo-600 hover:text-indigo-900 mr-2">Edit</button>
                            <button data-id="${supplier.supplier_id}" class="delete-btn text-red-600 hover:text-red-900">Delete</button>
                        </td>
                    `;
                    suppliersTableBody.appendChild(row);
                });

                // Add event listeners for edit and delete buttons
                document.querySelectorAll('.edit-btn').forEach(button => {
                    button.addEventListener('click', handleEditSupplier);
                });
                document.querySelectorAll('.delete-btn').forEach(button => {
                    button.addEventListener('click', handleDeleteSupplier);
                });

            } else if (suppliers && Array.isArray(suppliers)) { // Check if it's an empty array
                suppliersTableBody.innerHTML = `<tr><td colspan="7" class="px-6 py-4 whitespace-nowrap text-center text-sm text-gray-500">No suppliers found.</td></tr>`;
            } else { // Handle case where API response is not an array (e.g., error)
                suppliersTableBody.innerHTML = `<tr><td colspan="7" class="px-6 py-4 whitespace-nowrap text-center text-sm text-gray-500">Error loading suppliers.</td></tr>`;
                console.error("API response for suppliers data was not an array or null:", suppliersResponse);
                showMessageBox("Failed to load suppliers. Invalid data from server.", 'error');
            }
        } catch (error) {
            console.error('Error loading suppliers (catch block):', error);
            showMessageBox('Failed to load suppliers. Please check console.', 'error');
            suppliersTableBody.innerHTML = `<tr><td colspan="7" class="px-6 py-4 whitespace-nowrap text-center text-sm text-gray-500">Error loading suppliers. Please try again.</td></tr>`;
        }
    }

    async function handleSaveSupplier(event) {
        event.preventDefault();

        const supplierId = supplierIdInput.value;
        const supplierName = supplierNameInput.value.trim();

        if (!supplierName) {
            showMessageBox('Supplier Name is required.', 'error');
            return;
        }

        const data = {
            supplier_name: supplierName,
            contact_person: contactPersonInput.value.trim(),
            email: emailInput.value.trim(),
            phone: phoneInput.value.trim(),
            address_line1: addressLine1Input.value.trim(),
            address_line2: addressLine2Input.value.trim(),
            city: cityInput.value.trim(),
            state: stateInput.value.trim(),
            zip_code: zipCodeInput.value.trim(),
            country: countryInput.value.trim(),
            payment_terms: paymentTermsInput.value.trim(),
            tax_id: taxIdInput.value.trim(),
            is_active: isActiveCheckbox.checked ? 1 : 0
        };

        let result;
        try {
            saveSupplierBtn.disabled = true;
            saveSupplierBtn.innerHTML = `
                <svg class="animate-spin -ml-1 mr-2 h-4 w-4 text-white inline" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                    <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
                    <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                </svg>
                Saving...
            `;

            if (supplierId) {
                // Update existing supplier
                data.supplier_id = supplierId; // Add ID for PUT request
                result = await fetchData('api/suppliers.php', 'PUT', data);
            } else {
                // Create new supplier
                result = await fetchData('api/suppliers.php', 'POST', data);
            }

            if (result && result.success) {
                showMessageBox(`Supplier ${supplierId ? 'updated' : 'created'} successfully!`, 'success');
                resetSupplierForm();
                await loadSuppliers(); // Reload list
            } else if (result && result.message) {
                showMessageBox(result.message, 'error');
            }
        } catch (error) {
            console.error('Error saving supplier:', error);
            showMessageBox('Failed to save supplier. Please check console.', 'error');
        } finally {
            saveSupplierBtn.disabled = false;
            saveSupplierBtn.textContent = supplierId ? 'Update Supplier' : 'Save Supplier';
        }
    }

    async function handleEditSupplier(event) {
        const supplierId = event.target.dataset.id;
        const supplierResponse = await fetchData(`api/suppliers.php?id=${supplierId}`);
        const supplier = supplierResponse.data; // Access data property

        if (supplier) {
            supplierIdInput.value = supplier.supplier_id;
            supplierNameInput.value = supplier.supplier_name;
            contactPersonInput.value = supplier.contact_person;
            emailInput.value = supplier.email;
            phoneInput.value = supplier.phone;
            addressLine1Input.value = supplier.address_line1;
            addressLine2Input.value = supplier.address_line2;
            cityInput.value = supplier.city;
            stateInput.value = supplier.state;
            zipCodeInput.value = supplier.zip_code;
            countryInput.value = supplier.country;
            paymentTermsInput.value = supplier.payment_terms;
            taxIdInput.value = supplier.tax_id;
            isActiveCheckbox.checked = supplier.is_active == 1;

            supplierFormTitle.textContent = 'Edit Supplier';
            saveSupplierBtn.textContent = 'Update Supplier';
            cancelEditBtn.style.display = 'inline-flex';
        } else if (supplierResponse && supplierResponse.message) {
            showMessageBox(supplierResponse.message, 'error');
        } else {
            showMessageBox('Failed to load supplier for editing.', 'error');
        }
    }

    async function handleDeleteSupplier(event) {
        const supplierId = event.target.dataset.id;
        if (confirm('Are you sure you want to delete this supplier? This action cannot be undone if there are associated receipts.')) { // Use custom modal in production
            try {
                const result = await fetchData(`api/suppliers.php?id=${supplierId}`, 'DELETE');
                if (result && result.success) {
                    showMessageBox('Supplier deleted successfully!', 'success');
                    await loadSuppliers(); // Reload list
                } else if (result && result.message) {
                    showMessageBox(result.message, 'error');
                }
            } catch (error) {
                console.error('Error deleting supplier:', error);
                showMessageBox('Failed to delete supplier. Please check console.', 'error');
            }
        }
    }

    function resetSupplierForm() {
        supplierForm.reset();
        supplierIdInput.value = '';
        isActiveCheckbox.checked = true; // Default to active
        supplierFormTitle.textContent = 'Add New Supplier';
        saveSupplierBtn.textContent = 'Save Supplier';
        cancelEditBtn.style.display = 'none';
    }

    // --- End Functions ---
});