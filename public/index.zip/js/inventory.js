// public/js/inventory.js

// Global variables currentWarehouseId and currentWarehouseName are assumed to be available from main.js
// window.allWarehouses is assumed to be globally available from dashboard.js -> main.js population.

document.addEventListener('DOMContentLoaded', () => {
    const inventoryTableBody = document.getElementById('inventoryTableBody');
    const searchProductInput = document.getElementById('searchProductInput');
    const searchLocationSelect = document.getElementById('searchLocationSelect');
    const searchBtn = document.getElementById('searchBtn');
    const clearSearchBtn = document.getElementById('clearSearchBtn');
    const adjustForm = document.getElementById('adjustForm');
    const logoutBtn = document.getElementById('logoutBtn');

    // New inputs for batch/expiry
    const adjustBatchNumberInput = document.getElementById('adjustBatchNumber');
    const adjustExpiryDateInput = document.getElementById('adjustExpiryDate');

    // Elements for adjustment form barcode inputs (declared here for setupBarcodeScanner)
    const adjustProductBarcode = document.getElementById('adjustProductBarcode');
    const adjustCurrentLocation = document.getElementById('adjustCurrentLocation');
    const adjustNewLocation = document.getElementById('adjustNewLocation');


    let allProducts = []; // Stores all products for barcode lookup
    let allLocationsData = []; // Stores all locations data (for capacity calculations in dropdown)


    // Initialize page
    initializePage();

    // --- Event Listeners ---
    if (searchBtn) {
        searchBtn.addEventListener('click', loadInventory);
    }
    if (clearSearchBtn) {
        clearSearchBtn.addEventListener('click', () => {
            searchProductInput.value = '';
            searchLocationSelect.value = ''; // Clear dropdown selection
            loadInventory();
        });
    }
    if (searchLocationSelect) {
        searchLocationSelect.addEventListener('change', loadInventory);
    }

    if (adjustForm) {
        adjustForm.addEventListener('submit', handleInventoryAdjustment);
    }
    if (logoutBtn) {
        logoutBtn.addEventListener('click', handleLogout);
    }

    // Setup barcode scanning for the adjustment form inputs
    if (adjustProductBarcode) {
        setupBarcodeScanner('adjustProductBarcode', (barcode) => {
            adjustProductBarcode.value = barcode;
            showMessageBox(`Product Barcode Scanned: ${barcode}`, 'info');
        });
    }
    if (adjustCurrentLocation) {
        setupBarcodeScanner('adjustCurrentLocation', (barcode) => {
            adjustCurrentLocation.value = barcode;
            showMessageBox(`Current Location Scanned: ${barcode}`, 'info');
        });
    }
    if (adjustNewLocation) {
        setupBarcodeScanner('adjustNewLocation', (barcode) => {
            adjustNewLocation.value = barcode;
            showMessageBox(`New Location Scanned: ${barcode}`, 'info');
        });
    }


    // --- Core Initialization Function ---
    async function initializePage() {
        if (currentWarehouseId) {
            await loadProductsForDropdown(); // Load products for barcode lookup
            await loadAllLocationsData(currentWarehouseId); // Load all locations data for capacity display
            await loadLocationsForFilterDropdown(currentWarehouseId); // Populate filter dropdown
            await loadInventory(); // Load inventory for the selected warehouse
        } else {
            showMessageBox('Please select a warehouse on the Dashboard to view inventory.', 'warning', 5000);
            inventoryTableBody.innerHTML = `<tr><td colspan="7" class="px-6 py-4 whitespace-nowrap text-center text-sm text-gray-500">Please select a warehouse on the Dashboard.</td></tr>`;
            if (searchLocationSelect) searchLocationSelect.innerHTML = '<option value="">Select a warehouse first.</option>';
            if (adjustForm) adjustForm.querySelector('button[type="submit"]').disabled = true;
        }
    }


    // --- Data Loading Functions ---

    // Load products for internal barcode lookup (similar to outbound.js)
    async function loadProductsForDropdown() {
        try {
            const productsResponse = await fetchData('api/products.php');
            allProducts = productsResponse.data; // Store globally for barcode lookup
        } catch (error) {
            console.error('Error loading products for barcode lookup:', error);
            showMessageBox('Error loading product data.', 'error');
        }
    }

    /**
     * Loads ALL locations data for the current warehouse into allLocationsData array.
     * This includes capacity info from api/locations.php.
     * @param {number} warehouseId
     */
    async function loadAllLocationsData(warehouseId) {
        if (!warehouseId) return;
        try {
            const locationsResponse = await fetchData(`api/locations.php?warehouse_id=${warehouseId}`);
            allLocationsData = locationsResponse.data; // Store full location data locally
        } catch (error) {
            console.error('Error loading ALL locations data:', error);
            showMessageBox('Error loading location data.', 'error');
        }
    }

    /**
     * Populates the main search/filter dropdown for locations.
     * @param {number} warehouseId
     */
    async function loadLocationsForFilterDropdown(warehouseId) {
        if (!searchLocationSelect || !warehouseId) return;
        searchLocationSelect.innerHTML = '<option value="">All Locations</option>'; // Reset

        if (allLocationsData && Array.isArray(allLocationsData)) {
            // Filter to show active locations in the filter dropdown
            const activeLocations = allLocationsData.filter(loc => loc.is_active);
            activeLocations.sort((a, b) => a.location_code.localeCompare(b.location_code));

            activeLocations.forEach(location => {
                const option = document.createElement('option');
                option.value = location.location_code; // Use location_code as value for filter dropdown
                // Display capacity info (occupied/max units) for filter dropdown
                let capacityText = '';
                if (location.max_capacity_units !== null) {
                    capacityText = ` (${location.occupied_capacity}/${location.max_capacity_units} units)`;
                } else {
                    capacityText = ' (No max capacity)';
                }
                option.textContent = `${location.location_code}${capacityText}`;
                searchLocationSelect.appendChild(option);
            });
        } else {
            searchLocationSelect.innerHTML = '<option value="">No locations found</option>';
        }
    }


    async function loadInventory() {
        if (!inventoryTableBody || !currentWarehouseId) return;

        inventoryTableBody.innerHTML = `<tr><td colspan="7" class="px-6 py-4 whitespace-nowrap text-center text-sm text-gray-500">Loading inventory...</td></tr>`;

        const product_search_barcode = searchProductInput.value.trim();
        const location_search_code = searchLocationSelect.value; // This is location_code from dropdown

        let url = 'api/inventory.php?';
        let queryParams = [];
        // warehouse_id is automatically added by fetchData

        if (product_search_barcode) {
            // Send product_id for summarized view, not barcode directly, as backend expects product_id for summary query
            const product = allProducts.find(p => p.barcode === product_search_barcode);
            if (product) {
                queryParams.push(`product_id=${product.product_id}`);
            } else {
                showMessageBox(`Product barcode "${product_search_barcode}" not found for search.`, 'warning');
                inventoryTableBody.innerHTML = `<tr><td colspan="7" class="px-6 py-4 whitespace-nowrap text-center text-sm text-gray-500">Product not found.</td></tr>`;
                return;
            }
        }
        if (location_search_code) {
            // For location filter, use location_code
            queryParams.push(`location_code=${encodeURIComponent(location_search_code)}`);
        }
        if (queryParams.length > 0) {
            url += queryParams.join('&');
        }
        console.log("Fetching inventory with URL:", url);

        try {
            const inventoryResponse = await fetchData(url);
            // This API call now returns summarized data by location or detailed inventory items
            // Depending on if product_id/barcode is sent, it will either return:
            // { location_id, location_code, warehouse_id, total_quantity_at_location } (for product summary)
            // OR
            // { inventory_id, quantity, batch_number, ... product & location details } (for detailed inventory)
            const inventoryItems = inventoryResponse.data;
            console.log("Inventory data received:", inventoryItems);


            if (inventoryItems && Array.isArray(inventoryItems) && inventoryItems.length > 0) {
                inventoryTableBody.innerHTML = '';
                // Determine if the data is summarized by location (contains total_quantity_at_location)
                const isSummarizedByLocation = inventoryItems[0].total_quantity_at_location !== undefined;

                if (isSummarizedByLocation) {
                    // Render summarized view (Product / Locations / Total Quantity)
                    inventoryItems.forEach(itemSummary => {
                        const row = document.createElement('tr');
                        // Find the warehouse name for the location
                        const warehouse = window.allWarehouses?.find(wh => wh.warehouse_id == itemSummary.warehouse_id);
                        const warehouseName = warehouse ? ` [${warehouse.warehouse_name}]` : '';

                        row.innerHTML = `
                            <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">${itemSummary.sku || 'N/A'}</td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">${itemSummary.product_name || 'N/A'}</td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">${itemSummary.barcode || 'N/A'}</td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">${itemSummary.location_code}${warehouseName}</td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">${itemSummary.total_quantity_at_location}</td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">Multiple Batches</td> <!-- Simplified for summary -->
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">N/A</td> <!-- Simplified for summary -->
                        `;
                        inventoryTableBody.appendChild(row);
                    });
                } else {
                    // Render detailed inventory view (default, or when location filter is active)
                    inventoryItems.forEach(item => {
                        const row = document.createElement('tr');
                        // Find the warehouse name for the location
                        const warehouse = window.allWarehouses?.find(wh => wh.warehouse_id == currentWarehouseId); // Or item.warehouse_id if inventory.php returned it
                        const warehouseName = warehouse ? ` [${warehouse.warehouse_name}]` : '';

                        row.innerHTML = `
                            <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">${item.sku}</td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">${item.product_name}</td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">${item.barcode || 'N/A'}</td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">${item.location_code}${warehouseName}</td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">${item.quantity}</td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">${item.batch_number || 'N/A'}${item.expiry_date ? ` (${item.expiry_date})` : ''}</td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">${item.last_moved_at ? new Date(item.last_moved_at).toLocaleDateString() : 'N/A'}</td>
                        `;
                        inventoryTableBody.appendChild(row);
                    });
                }
            } else if (inventoryItems && Array.isArray(inventoryItems)) { // Empty array
                inventoryTableBody.innerHTML = `<tr><td colspan="7" class="px-6 py-4 whitespace-nowrap text-center text-sm text-gray-500">No inventory found matching criteria.</td></tr>`;
            } else {
                inventoryTableBody.innerHTML = `<tr><td colspan="7" class="px-6 py-4 whitespace-nowrap text-center text-sm text-gray-500">Error loading inventory data.</td></tr>`;
                console.error("API response for inventory data was not an array or null:", inventoryResponse);
                showMessageBox('Failed to load inventory. Invalid data from server.', 'error');
            }
        } catch (error) {
            console.error('Error loading inventory (catch block):', error);
            showMessageBox('Failed to load inventory. Please check console.', 'error');
            inventoryTableBody.innerHTML = `<tr><td colspan="7" class="px-6 py-4 whitespace-nowrap text-center text-sm text-gray-500">Error loading inventory. Please try again.</td></tr>`;
        }
    }


    // --- Operations Functions ---

    async function handleInventoryAdjustment(event) {
        event.preventDefault();

        const actionType = document.getElementById('adjustmentType').value;
        const productBarcode = document.getElementById('adjustProductBarcode').value.trim();
        const currentLocationBarcode = document.getElementById('adjustCurrentLocation').value.trim();
        const quantityChange = parseInt(document.getElementById('adjustQuantity').value, 10);
        const newLocationBarcode = document.getElementById('adjustNewLocation').value.trim();

        const batchNumber = adjustBatchNumberInput.value.trim();
        const expiryDate = adjustExpiryDateInput.value.trim();

        if (!productBarcode) {
            showMessageBox('Product Barcode is required.', 'error');
            return;
        }
        if (!currentLocationBarcode) {
            showMessageBox('Current Location Barcode is required.', 'error');
            return;
        }
        if (isNaN(quantityChange) || quantityChange === 0) {
            showMessageBox('Quantity Change must be a valid non-zero number.', 'error');
            return;
        }
        if (actionType === 'transfer' && !newLocationBarcode) {
            showMessageBox('New Location Barcode is required for transfer.', 'error');
            return;
        }


        const data = {
            action_type: actionType,
            product_barcode: productBarcode,
            current_location_barcode: currentLocationBarcode,
            quantity_change: quantityChange,
            new_location_barcode: newLocationBarcode,
            batch_number: batchNumber || null,
            expiry_date: expiryDate || null
        };

        try {
            const result = await fetchData('api/inventory.php', 'POST', data);

            if (result && result.success) {
                showMessageBox(result.message, 'success');
                adjustForm.reset();
                document.getElementById('adjustCurrentLocation').value = '';
                document.getElementById('adjustNewLocation').value = '';
                document.getElementById('adjustProductBarcode').value = '';
                document.getElementById('adjustQuantity').value = '0';
                document.getElementById('adjustBatchNumber').value = '';
                document.getElementById('adjustExpiryDate').value = '';

                document.getElementById('adjustmentType').value = 'adjust_quantity';
                document.getElementById('newLocationField').style.display = 'none';

                await loadInventory(); // Reload inventory list to reflect changes
                await loadLocationsForFilterDropdown(currentWarehouseId); // Refresh location dropdown capacity info
            } else if (result && result.message) {
                showMessageBox(result.message, 'error');
            }
        } catch (error) {
            console.error('Error during inventory adjustment:', error);
            showMessageBox('Failed to perform adjustment. Please check console.', 'error');
        }
    }

    // Handle logout
    async function handleLogout(event) {
        event.preventDefault();

        try {
            const result = await fetchData('api/auth.php?action=logout');

            if (result && result.success) {
                showMessageBox('Logged out successfully.', 'success');
                setTimeout(() => {
                    window.location.href = 'index.html';
                }, 1000);
            } else {
                showMessageBox('Logout failed. Please try again.', 'error');
            }
        } catch (error) {
            console.error('Logout error:', error);
            showMessageBox('Logout failed. Please try again.', 'error');
        }
    }
});