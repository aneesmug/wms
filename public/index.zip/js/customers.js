// public/js/customers.js

document.addEventListener('DOMContentLoaded', () => {
    // --- DOM Elements ---
    const customerForm = document.getElementById('customerForm');
    const customerFormTitle = document.getElementById('customerFormTitle');
    const customerIdInput = document.getElementById('customerId');
    const customersTableBody = document.getElementById('customersTableBody');
    const saveCustomerBtn = document.getElementById('saveCustomerBtn');
    const cancelEditBtn = document.getElementById('cancelEditBtn');
    const logoutBtn = document.getElementById('logoutBtn');

    // --- Form Fields ---
    const customerNameInput = document.getElementById('customerName');
    const contactPersonInput = document.getElementById('contactPerson');
    const emailInput = document.getElementById('email');
    const phoneInput = document.getElementById('phone');
    const addressLine1Input = document.getElementById('addressLine1');
    const addressLine2Input = document.getElementById('addressLine2');
    const cityInput = document.getElementById('city');
    const stateInput = document.getElementById('state');
    const zipCodeInput = document.getElementById('zipCode');
    const countryInput = document.getElementById('country');
    
    // --- Get Current User's Role from localStorage ---
    const currentWarehouseRole = localStorage.getItem('current_warehouse_role');

    // --- Event Listeners ---
    if (customerForm) {
        customerForm.addEventListener('submit', handleSaveCustomer);
    }
    if (cancelEditBtn) {
        cancelEditBtn.addEventListener('click', resetCustomerForm);
    }
    if (logoutBtn) {
        logoutBtn.addEventListener('click', (event) => {
            event.preventDefault();
            handleLogout();
        });
    }

    // --- Initial Page Load ---
    initializePage();

    // --- Core Functions ---

    /**
     * Initializes the page, setting UI visibility based on the user's role.
     */
    async function initializePage() {
        // Customers are not tied to a specific warehouse, so we don't check for currentWarehouseId
        // However, we still use the role to control access to actions.
        const canManage = currentWarehouseRole === 'operator' || currentWarehouseRole === 'manager';
        
        if (customerForm) {
            if (canManage) {
                customerForm.style.display = 'grid'; // Show form
            } else {
                customerForm.style.display = 'none'; // Hide form for viewers
                showMessageBox('You have view-only permissions for customers.', 'info', 4000);
            }
        }
        
        await loadCustomers();
    }

    /**
     * Fetches and displays the list of customers. Action buttons are shown based on role.
     */
    async function loadCustomers() {
        if (!customersTableBody) return;
        customersTableBody.innerHTML = `<tr><td colspan="6" class="px-6 py-4 text-center">Loading customers...</td></tr>`;

        const response = await fetchData('api/customers.php');
        customersTableBody.innerHTML = ''; // Clear table

        if (response && response.success && Array.isArray(response.data)) {
            if (response.data.length === 0) {
                customersTableBody.innerHTML = `<tr><td colspan="6" class="px-6 py-4 text-center">No customers found.</td></tr>`;
                return;
            }

            const canEdit = currentWarehouseRole === 'operator' || currentWarehouseRole === 'manager';
            const canDelete = currentWarehouseRole === 'manager';

            response.data.forEach(customer => {
                const row = document.createElement('tr');
                let actionsHtml = '';

                if (canEdit) {
                    actionsHtml += `<button data-id="${customer.customer_id}" class="edit-btn text-indigo-600 hover:text-indigo-900 mr-3">Edit</button>`;
                }
                if (canDelete) {
                    actionsHtml += `<button data-id="${customer.customer_id}" class="delete-btn text-red-600 hover:text-red-900">Delete</button>`;
                }
                if (!actionsHtml) {
                    actionsHtml = `<span class="text-gray-500">View Only</span>`;
                }

                row.innerHTML = `
                    <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">${customer.customer_name}</td>
                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">${customer.contact_person || 'N/A'}</td>
                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">${customer.email || 'N/A'}</td>
                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">${customer.phone || 'N/A'}</td>
                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">${customer.city || 'N/A'}</td>
                    <td class="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">${actionsHtml}</td>
                `;
                customersTableBody.appendChild(row);
            });
            
            addTableButtonListeners();

        } else {
            customersTableBody.innerHTML = `<tr><td colspan="6" class="px-6 py-4 text-center">Error loading customers.</td></tr>`;
            showMessageBox(response?.message || "Failed to load customer data from server.", 'error');
        }
    }

    /**
     * Handles form submission for creating or updating a customer.
     */
    async function handleSaveCustomer(event) {
        event.preventDefault();
        
        const data = {
            customer_id: customerIdInput.value || null,
            customer_name: customerNameInput.value.trim(),
            contact_person: contactPersonInput.value.trim(),
            email: emailInput.value.trim(),
            phone: phoneInput.value.trim(),
            address_line1: addressLine1Input.value.trim(),
            address_line2: addressLine2Input.value.trim(),
            city: cityInput.value.trim(),
            state: stateInput.value.trim(),
            zip_code: zipCodeInput.value.trim(),
            country: countryInput.value.trim()
        };

        if (!data.customer_name) {
            showMessageBox('Customer Name is required.', 'error');
            return;
        }

        const isUpdating = !!data.customer_id;
        const method = isUpdating ? 'PUT' : 'POST';
        
        saveCustomerBtn.disabled = true;
        saveCustomerBtn.innerHTML = 'Saving...';

        const result = await fetchData('api/customers.php', method, data);
        
        if (result && result.success) {
            showMessageBox(result.message, 'success');
            resetCustomerForm();
            await loadCustomers();
        }

        saveCustomerBtn.disabled = false;
        saveCustomerBtn.textContent = isUpdating ? 'Update Customer' : 'Save Customer';
    }

    /**
     * Handles populating the form for editing when an 'Edit' button is clicked.
     */
    async function handleEditClick(event) {
        const id = event.target.dataset.id;
        const response = await fetchData(`api/customers.php?id=${id}`);
        if (response && response.success) {
            const customer = response.data;
            customerIdInput.value = customer.customer_id;
            customerNameInput.value = customer.customer_name;
            contactPersonInput.value = customer.contact_person;
            emailInput.value = customer.email;
            phoneInput.value = customer.phone;
            addressLine1Input.value = customer.address_line1;
            addressLine2Input.value = customer.address_line2;
            cityInput.value = customer.city;
            stateInput.value = customer.state;
            zipCodeInput.value = customer.zip_code;
            countryInput.value = customer.country;

            customerFormTitle.textContent = 'Edit Customer';
            saveCustomerBtn.textContent = 'Update Customer';
            cancelEditBtn.style.display = 'inline-flex';
            window.scrollTo({ top: 0, behavior: 'smooth' });
        } else {
            showMessageBox(response?.message || 'Failed to load customer for editing.', 'error');
        }
    }

    /**
     * Handles customer deletion.
     */
    async function handleDeleteClick(event) {
        const id = event.target.dataset.id;
        if (confirm('Are you sure you want to delete this customer? This may fail if they have existing orders.')) {
            const result = await fetchData(`api/customers.php?id=${id}`, 'DELETE');
            if (result && result.success) {
                showMessageBox('Customer deleted successfully!', 'success');
                await loadCustomers();
                resetCustomerForm();
            }
        }
    }

    /**
     * Resets the form to its default "Add New" state.
     */
    function resetCustomerForm() {
        customerForm.reset();
        customerIdInput.value = '';
        customerFormTitle.textContent = 'Add New Customer';
        saveCustomerBtn.textContent = 'Save Customer';
        cancelEditBtn.style.display = 'none';
    }

    /**
     * Adds event listeners to all dynamically created buttons in the table.
     */
    function addTableButtonListeners() {
        document.querySelectorAll('.edit-btn').forEach(button => {
            button.addEventListener('click', handleEditClick);
        });
        document.querySelectorAll('.delete-btn').forEach(button => {
            button.addEventListener('click', handleDeleteClick);
        });
    }

    /**
     * Handles the user logout process.
     */
    async function handleLogout() {
        const result = await fetchData('api/auth.php?action=logout');
        if (result && result.success) {
            redirectToLogin();
        } else {
            showMessageBox('Logout failed.', 'error');
        }
    }
});
